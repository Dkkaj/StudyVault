import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  FileText, 
  Edit3, 
  Trash2, 
  MoreVertical, 
  BookOpen, 
  Clock, 
  Hash,
  ChevronRight,
  Sparkles,
  Save,
  Maximize2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { cn } from '../lib/utils';
import ReactMarkdown from 'react-markdown';

interface Note {
  id: string;
  title: string;
  content: string;
  category: string;
  created_at: string;
}

export function Notes() {
  const { profile } = useAuth();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [editingTitle, setEditingTitle] = useState('');
  const [editingCategory, setEditingCategory] = useState('');

  const fetchNotes = async () => {
    if (!profile?.id) return;
    const { data } = await supabase
      .from('notes')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false });
    
    setNotes(data || []);
    setLoading(false);
  };

  React.useEffect(() => {
    fetchNotes();
  }, [profile]);

  const activeNote = notes.find(n => n.id === activeNoteId);

  const startEditing = (note: Note) => {
    setActiveNoteId(note.id);
    setEditingContent(note.content);
    setEditingTitle(note.title);
    setEditingCategory(note.category);
  };

  const saveNote = async () => {
    if (!activeNoteId || !profile) return;
    const { data, error } = await supabase
      .from('notes')
      .update({ 
        title: editingTitle, 
        content: editingContent, 
        category: editingCategory,
        updated_at: new Date().toISOString() 
      })
      .eq('id', activeNoteId)
      .select()
      .single();

    if (data) {
      setNotes(notes.map(n => n.id === activeNoteId ? data : n));
      setActiveNoteId(null);
    }
  };

  const createNote = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('notes')
      .insert({
        user_id: profile.id,
        title: 'Untitled Note',
        content: '',
        category: 'General'
      })
      .select()
      .single();

    if (data) {
      setNotes([data, ...notes]);
      startEditing(data);
    }
  };

  const deleteNote = async (id: string) => {
    await supabase.from('notes').delete().eq('id', id);
    setNotes(notes.filter(n => n.id !== id));
    if (activeNoteId === id) setActiveNoteId(null);
  };

  return (
    <div className="h-screen -m-8 flex overflow-hidden bg-gray-50/50">
       {/* Sidebar */}
       <div className="w-80 bg-white border-r flex flex-col h-full shadow-sm">
          <div className="p-8 border-b space-y-6">
             <div className="flex items-center justify-between">
                <h1 className="text-2xl font-black font-display tracking-tight flex items-center gap-2">
                  <Edit3 className="text-blue-600" /> Scribble
                </h1>
                <button 
                  onClick={createNote}
                  className="p-3 bg-blue-600 text-white rounded-xl shadow-lg hover:scale-105 transition-all"
                >
                   <Plus className="w-5 h-5" />
                </button>
             </div>
             <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Seach your notes..." 
                  className="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-xl text-sm outline-none border border-transparent focus:bg-white focus:border-blue-200"
                />
             </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-2">
             {notes.map(note => (
                <div 
                  key={note.id}
                  onClick={() => startEditing(note)}
                  className={cn(
                    "p-5 rounded-2xl transition-all cursor-pointer group",
                    activeNoteId === note.id ? "bg-blue-600 text-white shadow-xl shadow-blue-500/20" : "hover:bg-gray-100"
                  )}
                >
                   <div className="flex justify-between items-start mb-2">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest",
                        activeNoteId === note.id ? "bg-white/20 text-white" : "bg-gray-100 text-gray-400"
                      )}>
                         {note.category}
                      </span>
                      <button 
                        onClick={(e) => { e.stopPropagation(); deleteNote(note.id); }}
                        className={cn(
                          "p-1 opacity-0 group-hover:opacity-100 transition-opacity",
                          activeNoteId === note.id ? "text-white" : "text-gray-400 hover:text-red-600"
                        )}
                      >
                         <Trash2 className="w-4 h-4" />
                      </button>
                   </div>
                   <h3 className="font-bold truncate">{note.title}</h3>
                   <p className={cn(
                     "text-xs mt-2 line-clamp-2",
                     activeNoteId === note.id ? "text-blue-100" : "text-gray-400"
                   )}>
                      {note.content.replace(/[#*`]/g, '').slice(0, 80)}
                   </p>
                </div>
             ))}
          </div>
       </div>

       {/* Editor Area */}
       <div className="flex-1 flex flex-col bg-white">
          <AnimatePresence mode="wait">
            {activeNoteId ? (
               <motion.div 
                 key="editor"
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 exit={{ opacity: 0 }}
                 className="flex flex-col h-full"
               >
                  <header className="p-8 border-b flex items-center justify-between">
                     <div className="flex items-center gap-4 flex-1">
                        <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                           <FileText className="w-6 h-6" />
                        </div>
                        <input 
                           type="text" 
                           value={editingTitle}
                           onChange={e => setEditingTitle(e.target.value)}
                           className="text-2xl font-black font-display outline-none flex-1"
                        />
                        <input 
                           type="text" 
                           value={editingCategory}
                           onChange={e => setEditingCategory(e.target.value)}
                           placeholder="Category"
                           className="bg-gray-100 px-3 py-1 rounded-lg text-[10px] font-black uppercase text-gray-400 tracking-widest outline-none"
                        />
                     </div>
                     <div className="flex items-center gap-3">
                        <span className="text-xs text-gray-400 font-medium">Last saved: Just now</span>
                        <button 
                          onClick={saveNote}
                          className="px-8 py-3 bg-gray-900 text-white rounded-xl font-bold flex items-center gap-2 hover:bg-black transition-all shadow-xl shadow-black/10"
                        >
                           <Save className="w-4 h-4" /> Save Note
                        </button>
                     </div>
                  </header>

                  <div className="flex-1 flex divide-x overflow-hidden">
                     <textarea 
                        className="flex-1 p-12 bg-gray-50/50 outline-none resize-none font-mono leading-relaxed"
                        placeholder="Start writing with Markdown support..."
                        value={editingContent}
                        onChange={e => setEditingContent(e.target.value)}
                     />
                     <div className="flex-1 p-12 overflow-y-auto prose prose-blue max-w-none">
                        <div className="flex items-center gap-2 text-xs font-black uppercase text-blue-600 tracking-widest mb-8">
                           <Sparkles className="w-4 h-4" /> Live Preview
                        </div>
                        <ReactMarkdown>{editingContent}</ReactMarkdown>
                     </div>
                  </div>
               </motion.div>
            ) : (
               <motion.div 
                 key="empty"
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 className="flex-1 flex flex-col items-center justify-center space-y-6"
               >
                  <div className="w-24 h-24 bg-gray-50 text-gray-300 rounded-[2.5rem] flex items-center justify-center relative">
                     <BookOpen className="w-12 h-12" />
                     <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-600 text-white rounded-xl flex items-center justify-center shadow-lg">
                        <Edit3 className="w-4 h-4" />
                     </div>
                  </div>
                  <div className="text-center">
                     <h2 className="text-2xl font-black font-display">Capture your knowledge</h2>
                     <p className="text-gray-500 max-w-xs mx-auto mt-2">Select a note or create a new one to start writing with Markdown support.</p>
                  </div>
                  <button 
                    onClick={createNote}
                    className="px-10 py-4 bg-gray-900 text-white rounded-2xl font-black flex items-center gap-2 hover:bg-black transition-all shadow-lg"
                  >
                     <Plus className="w-5 h-5" /> Start New Scribble
                  </button>
               </motion.div>
            )}
          </AnimatePresence>
       </div>
    </div>
  );
}
