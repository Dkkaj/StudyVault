import React, { useState } from 'react';
import { 
  User, 
  Mail, 
  ShieldCheck, 
  CreditCard, 
  Calendar, 
  Clock, 
  Edit2, 
  CheckCircle2, 
  ArrowRight,
  LogOut,
  Camera,
  Target,
  Trophy,
  Activity
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { cn, formatDate } from '../lib/utils';

export function Profile() {
  const { user, profile, refreshProfile, isAdmin, isPremium } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [category, setCategory] = useState(profile?.category || 'Student');

  // Handle case where profile might be missing initially
  React.useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setCategory(profile.category || 'Student');
    }
  }, [profile]);

  const [newPassword, setNewPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);

  const handleChangePassword = async () => {
    if (!newPassword) return;
    setChangingPassword(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      alert('Password updated successfully!');
      setNewPassword('');
    } catch (e: any) {
      alert(e.message || 'Failed to update password');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleUpdateProfile = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { error } = await supabase
        .from('users')
        .update({ 
          full_name: fullName,
          category: category
        })
        .eq('id', user.id);
      
      if (error) throw error;
      await refreshProfile();
      setEditing(false);
    } catch (e) {
      console.error(e);
      alert('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  if (!profile && !loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <ShieldCheck className="w-12 h-12 text-gray-300" />
        <h2 className="text-xl font-bold">Profile not found</h2>
        <p className="text-gray-500">Your profile record is being initialized. Please refresh in a moment.</p>
        <button 
          onClick={() => window.location.reload()} 
          className="px-6 py-2 bg-blue-600 text-white rounded-xl font-bold"
        >
          Refresh Page
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="relative">
        {/* Header/Cover Placeholder */}
        <div className="h-48 rounded-[2.5rem] gradient-bg shadow-xl"></div>
        
        {/* Profile Info Overlay */}
        <div className="px-8 -mt-16 sm:-mt-20">
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-6">
            <div className="relative group">
              <div className="w-32 h-32 sm:w-40 sm:h-40 bg-white rounded-[2rem] p-4 shadow-xl border-4 border-white overflow-hidden">
                <div className="w-full h-full bg-gray-100 rounded-2xl flex items-center justify-center text-gray-400">
                  <User className="w-16 h-16 sm:w-20 sm:h-20" />
                </div>
              </div>
              <button className="absolute bottom-2 right-2 p-3 bg-blue-600 text-white rounded-xl shadow-lg hover:scale-110 transition-transform">
                <Camera className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex-1 text-center sm:text-left pb-4 space-y-2">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
                <h1 className="text-3xl font-black text-gray-900 font-display">
                  {editing ? (
                    <input 
                      type="text" 
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      className="bg-gray-100 border-none outline-none px-4 py-1 rounded-xl text-2xl w-full max-w-xs " 
                      autoFocus
                    />
                  ) : (
                    profile.full_name || 'Set your name'
                  )}
                </h1>
                {isPremium && (
                  <span className="px-3 py-1 bg-blue-600 text-white text-[10px] uppercase font-black tracking-widest rounded-full flex items-center gap-1 shadow-lg shadow-blue-500/20">
                    <ShieldCheck className="w-3 h-3" /> Pro Member
                  </span>
                )}
                {isAdmin && (
                    <span className="px-3 py-1 bg-purple-600 text-white text-[10px] uppercase font-black tracking-widest rounded-full flex items-center gap-1 shadow-lg shadow-purple-500/20">
                    <ShieldCheck className="w-3 h-3" /> Admin
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-sm text-gray-500 font-medium tracking-tight">
                {editing ? (
                  <select 
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="bg-gray-100 border-none outline-none px-3 py-1 rounded-lg text-sm font-bold text-blue-600"
                  >
                    <option value="Student">Student</option>
                    <option value="Science">Science</option>
                    <option value="Commerce">Commerce</option>
                    <option value="Arts">Arts</option>
                    <option value="Engineering">Engineering</option>
                    <option value="Medical">Medical</option>
                  </select>
                ) : (
                  <span className="flex items-center gap-1.5 px-3 py-1 bg-blue-50 text-blue-600 rounded-lg font-bold"><Trophy className="w-3 h-3" /> {profile.category || 'Student'}</span>
                )}
                <span className="flex items-center gap-1.5"><Mail className="w-4 h-4" /> {profile.email}</span>
                <span className="flex items-center gap-1.5 font-bold text-blue-600"><Target className="w-4 h-4" /> ID: {profile.unique_study_id}</span>
                <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /> Joined {formatDate(profile.created_at)}</span>
              </div>
            </div>

            <div className="flex gap-2">
              {editing ? (
                <>
                  <button 
                    onClick={() => setEditing(false)}
                    className="px-6 py-2.5 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-all text-sm"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleUpdateProfile}
                    disabled={loading}
                    className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all text-sm flex items-center gap-2"
                  >
                    {loading ? 'Saving...' : 'Save Changes'}
                  </button>
                </>
              ) : (
                <button 
                  onClick={() => setEditing(true)}
                  className="px-6 py-2.5 bg-white border text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all text-sm flex items-center gap-2 shadow-sm"
                >
                  <Edit2 className="w-4 h-4" /> Edit Profile
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8 px-4">
        {/* Account Settings */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border shadow-sm space-y-8">
            <div>
               <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                 <ShieldCheck className="text-blue-600" /> Account Security
               </h3>
               <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-5 rounded-2xl bg-gray-50 border border-gray-100 flex items-center justify-between group cursor-pointer hover:border-blue-200 transition-all">
                    <div className="space-y-1">
                      <p className="text-xs font-black uppercase text-gray-400 tracking-widest">Email Verification</p>
                      <p className="text-sm font-bold text-gray-900">Verified</p>
                    </div>
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  </div>
                  <div className="p-5 rounded-2xl bg-gray-50 border border-gray-100 flex items-center justify-between group cursor-pointer hover:border-blue-200 transition-all">
                    <div className="space-y-1">
                      <p className="text-xs font-black uppercase text-gray-400 tracking-widest">Two-Factor Auth</p>
                      <p className="text-sm font-bold text-gray-400 italic">Coming Soon</p>
                    </div>
                  </div>
               </div>

               <div className="pt-6 border-t font-display">
                  <h4 className="text-lg font-black mb-4">Security Settings</h4>
                  <div className="flex flex-col sm:flex-row gap-4">
                     <div className="flex-1 space-y-2">
                        <label className="text-xs font-black uppercase text-gray-400 tracking-widest">Update Password</label>
                        <input 
                          type="password" 
                          placeholder="New password"
                          className="w-full p-4 bg-gray-50 rounded-2xl border-none outline-none focus:ring-2 ring-blue-500/20 font-mono"
                          value={newPassword}
                          onChange={e => setNewPassword(e.target.value)}
                        />
                     </div>
                     <button 
                       onClick={handleChangePassword}
                       disabled={changingPassword}
                       className="sm:mt-6 px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all shadow-lg active:scale-95 disabled:opacity-50"
                     >
                        {changingPassword ? 'Updating...' : 'Update Password'}
                     </button>
                  </div>
               </div>
            </div>

            <div>
               <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                 <CreditCard className="text-blue-600" /> Subscription Details
               </h3>
               <div className="p-6 rounded-[2rem] bg-gradient-to-br from-gray-900 to-gray-800 text-white relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
                    <Trophy className="w-32 h-32" />
                  </div>
                  <div className="relative z-10 space-y-6">
                    <div className="flex items-center justify-between">
                       <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-black uppercase tracking-widest border border-white/20">Current Plan</span>
                       <span className="text-blue-400 font-bold flex items-center gap-1 text-sm"><Activity className="w-4 h-4" /> {profile.subscription_status.toUpperCase()}</span>
                    </div>
                    <div>
                      <h4 className="text-3xl font-black">{isPremium ? 'PRO PASS' : 'FREE TIER'}</h4>
                      <p className="text-gray-400 text-sm mt-1">
                        {isPremium 
                          ? `Valid until ${profile.subscription_expires_at ? new Date(profile.subscription_expires_at).toLocaleDateString() : 'Forever'}`
                          : 'Unlock AI features with a Pro subscription'}
                      </p>
                    </div>
                    <button 
                      onClick={() => navigate('/subscription')}
                      className="w-full py-4 bg-white text-gray-900 rounded-xl font-black hover:bg-gray-100 transition-all flex items-center justify-center gap-2"
                    >
                      {isPremium ? 'Manage Billing' : 'Upgrade to Pro'} <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
               </div>
            </div>
          </div>
        </div>

        {/* Sidebar Actions */}
        <div className="md:col-span-1 space-y-6">
           <div className="bg-white p-8 rounded-[2.5rem] border shadow-sm space-y-6">
              <h3 className="font-bold text-gray-900 border-b pb-4">Activity Summary</h3>
              <div className="space-y-4">
                 <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 font-medium">Study Field</span>
                    <span className="font-bold text-blue-600">{profile.category || 'General'}</span>
                 </div>
                 <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 font-medium">Study Streak</span>
                    <span className="font-bold text-orange-500">5 Days</span>
                 </div>
                 <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 font-medium">Total Focus Time</span>
                    <span className="font-bold text-blue-600">42 Hours</span>
                 </div>
                 <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 font-medium">Quizzes Taken</span>
                    <span className="font-bold text-purple-600">18</span>
                 </div>
              </div>
           </div>

           <button 
             onClick={handleLogout}
             className="w-full p-4 bg-red-50 text-red-600 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-red-600 hover:text-white transition-all shadow-sm"
           >
             <LogOut className="w-5 h-5" /> Logout from Session
           </button>
        </div>
      </div>
    </div>
  );
}
