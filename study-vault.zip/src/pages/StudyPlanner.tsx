import React, { useState } from 'react';
import { 
  Wand2, 
  Calendar, 
  Clock, 
  Plus, 
  Trash2, 
  ChevronRight, 
  Loader2, 
  Sparkles,
  BookOpen,
  CheckCircle2,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import { generateStudyPlan } from '../services/geminiService';

interface Subject {
  id: string;
  name: string;
  priority: 'low' | 'medium' | 'high';
}

interface Chapter {
  id: string;
  subjectId: string;
  name: string;
}

export function StudyPlanner() {
  const { isPremium } = useAuth();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [examDate, setExamDate] = useState('');
  const [targetHours, setTargetHours] = useState('4');
  const [loading, setLoading] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<any>(null);

  const [newSubject, setNewSubject] = useState('');
  const [newChapter, setNewChapter] = useState('');
  const [activeSubjectId, setActiveSubjectId] = useState('');

  const addSubject = () => {
    if (!newSubject.trim()) return;
    const id = Date.now().toString();
    setSubjects([...subjects, { id, name: newSubject, priority: 'medium' }]);
    setNewSubject('');
    setActiveSubjectId(id);
  };

  const addChapter = () => {
    if (!newChapter.trim() || !activeSubjectId) return;
    setChapters([...chapters, { id: Date.now().toString(), subjectId: activeSubjectId, name: newChapter }]);
    setNewChapter('');
  };

  const generatePlan = async () => {
    if (!isPremium) {
      alert('Upgrade to Pro to use AI Planner!');
      return;
    }
    
    setLoading(true);
    try {
      const data = await generateStudyPlan(
        subjects.map(s => s.name),
        chapters.map(c => c.name),
        examDate,
        parseInt(targetHours)
      );
      setGeneratedPlan(data);
    } catch (e) {
      console.error(e);
      alert('Failed to generate study plan. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display flex items-center gap-2">
            <Wand2 className="text-blue-600" />
            AI Study Planner
          </h1>
          <p className="text-gray-500">Let AI optimize your revision based on your syllabus.</p>
        </div>
        {!isPremium && (
          <div className="px-4 py-2 bg-yellow-50 border border-yellow-100 rounded-xl flex items-center gap-2 text-yellow-700 text-sm font-medium">
            <Sparkles className="w-4 h-4" /> Upgrade to unlock AI features
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Step 1: Syllabus Input */}
        <div className="lg:col-span-1 space-y-6">
          <section className="bg-white p-6 rounded-[2rem] border shadow-sm space-y-6">
            <h3 className="font-bold text-gray-900 border-b pb-4">1. Syllabus Details</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-bold text-gray-700 block mb-2">Exam Date</label>
                <input 
                  type="date" 
                  value={examDate}
                  onChange={e => setExamDate(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 focus:border-blue-500 outline-none transition-all"
                />
              </div>

              <div>
                <label className="text-sm font-bold text-gray-700 block mb-2">Hours Per Day</label>
                <select 
                  value={targetHours}
                  onChange={e => setTargetHours(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-100 focus:border-blue-500 outline-none transition-all"
                >
                  <option value="2">2 Hours (Casual)</option>
                  <option value="4">4 Hours (Regular)</option>
                  <option value="6">6 Hours (Serious)</option>
                  <option value="8">8+ Hours (Warrior)</option>
                </select>
              </div>

              <div className="pt-4 space-y-4">
                <label className="text-sm font-bold text-gray-700 block">Subjects & Chapters</label>
                
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    placeholder="New Subject..."
                    value={newSubject}
                    onChange={e => setNewSubject(e.target.value)}
                    className="flex-1 px-4 py-2 rounded-xl border bg-gray-50 focus:bg-white outline-none text-sm"
                  />
                  <button onClick={addSubject} className="p-2 bg-blue-600 text-white rounded-xl hover:scale-110 transition-transform">
                    <Plus className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {subjects.map(s => (
                    <button
                      key={s.id}
                      onClick={() => setActiveSubjectId(s.id)}
                      className={cn(
                        "px-3 py-1 rounded-lg text-xs font-bold border transition-all",
                        activeSubjectId === s.id ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 hover:border-blue-200"
                      )}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>

                <AnimatePresence>
                  {activeSubjectId && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-4 bg-gray-50 rounded-2xl border border-dashed border-gray-200 space-y-3"
                    >
                      <p className="text-[10px] uppercase font-black text-gray-400 tracking-widest">Adding Chapters to {subjects.find(s => s.id === activeSubjectId)?.name}</p>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="Chapter name..."
                          value={newChapter}
                          onChange={e => setNewChapter(e.target.value)}
                          className="flex-1 px-4 py-2 rounded-xl bg-white border border-transparent outline-none text-sm focus:border-blue-200"
                        />
                        <button onClick={addChapter} className="p-2 bg-gray-900 text-white rounded-xl">
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="space-y-1">
                        {chapters.filter(c => c.subjectId === activeSubjectId).map((c, i) => (
                          <div key={i} className="flex items-center justify-between group p-1">
                            <span className="text-sm text-gray-600">• {c.name}</span>
                            <button className="opacity-0 group-hover:opacity-100 text-red-400"><Trash2 className="w-3 h-3" /></button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button
                onClick={generatePlan}
                disabled={loading || subjects.length === 0}
                className="w-full py-4 gradient-bg text-white font-bold rounded-2xl hover:shadow-xl hover:shadow-blue-500/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-5 h-5" /> Generate My Plan</>}
              </button>
            </div>
          </section>
        </div>

        {/* Step 2: Plan Preview */}
        <div className="lg:col-span-2">
          {!generatedPlan ? (
             <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-12 bg-white rounded-[2rem] border border-dashed border-gray-200 text-center space-y-4">
                <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center animate-bounce">
                  <Brain className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Your AI Plan Awaits</h3>
                <p className="text-gray-500 text-sm max-w-sm">
                  Fill in your syllabus details and click generate. Our AI will analyze your chapters and create a custom spaced-repetition plan for you.
                </p>
             </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              {/* Daily Checklist */}
              <section className="bg-white rounded-[2rem] border shadow-sm overflow-hidden">
                <div className="p-6 bg-blue-600 text-white flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold flex items-center gap-2"><CheckCircle2 /> Daily Study Goals</h3>
                    <p className="text-blue-100 text-xs">Based on your optimized timetable</p>
                  </div>
                  <button className="p-2 bg-white/20 rounded-xl hover:bg-white/30 transition-all">
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  {generatedPlan.dailyGoals.map((goal: string, i: number) => (
                    <div key={i} className="flex gap-4 p-4 rounded-2xl bg-gray-50 hover:bg-white border border-transparent hover:border-gray-100 transition-all cursor-pointer group">
                      <div className="w-6 h-6 rounded-lg border-2 border-gray-300 mt-1 shrink-0 flex items-center justify-center group-hover:border-blue-500 transition-colors"></div>
                      <p className="text-gray-700 font-medium">{goal}</p>
                    </div>
                  ))}
                </div>
              </section>

              {/* Master Timetable */}
              <section className="space-y-4">
                <h3 className="text-xl font-bold">Recommended Schedule</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {generatedPlan.timetable.map((day: any, i: number) => (
                    <div key={i} className="p-6 bg-white rounded-3xl border shadow-sm group hover:border-blue-200 transition-all">
                      <div className="flex justify-between items-start mb-4">
                        <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-xs font-bold uppercase tracking-widest">{day.day}</span>
                        <div className="flex items-center gap-1 text-gray-400 text-xs">
                          <Clock className="w-3 h-3" /> {day.duration}
                        </div>
                      </div>
                      <h4 className="font-bold text-lg text-gray-900 group-hover:text-blue-600 transition-colors">{day.subject}</h4>
                      <p className="text-sm font-medium text-gray-500 border-l-2 border-gray-100 pl-3 mt-2">{day.chapter}</p>
                      <div className="mt-4 pt-4 border-t border-gray-50 text-xs text-blue-600 font-semibold italic">
                        "Focus on: {day.focus}"
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Revision Planner */}
              <section className="bg-white p-8 rounded-[2rem] border shadow-sm space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold">Revision (Spaced Repetition)</h3>
                </div>
                <div className="space-y-4">
                  {generatedPlan.revisionSchedule.map((rev: any, i: number) => (
                    <div key={i} className="flex items-center gap-6 p-4 rounded-2xl border border-gray-100 group">
                      <div className="flex flex-col items-center justify-center w-16 h-16 rounded-2xl bg-gray-50 text-gray-900 shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-all">
                        <span className="text-[10px] uppercase font-black opacity-50">Rev.</span>
                        <span className="text-lg font-bold">{i + 1}</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold">{rev.topic}</h4>
                        <div className="flex items-center gap-4 mt-1">
                           <span className="text-[10px] text-gray-500 flex items-center gap-1"><Calendar /> {rev.date}</span>
                           <span className="text-[10px] text-purple-600 font-bold uppercase tracking-widest">{rev.method}</span>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-300" />
                    </div>
                  ))}
                </div>
                <div className="mt-8 p-6 bg-purple-50 rounded-2xl text-purple-700 italic text-sm">
                   <h5 className="font-bold mb-2 uppercase text-[10px] tracking-widest">Quote of the Day</h5>
                   "{generatedPlan.motivation}"
                </div>
              </section>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
