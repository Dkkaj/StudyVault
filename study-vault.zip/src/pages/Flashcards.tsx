import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  ChevronLeft, 
  ChevronRight, 
  RefreshCcw, 
  Layers, 
  Brain,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';

interface Flashcard {
  id: string;
  front: string;
  back: string;
  knowledge: 'hard' | 'good' | 'easy' | null;
}

export function Flashcards() {
  const { profile } = useAuth();
  const [cards, setCards] = useState<Flashcard[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newFront, setNewFront] = useState('');
  const [newBack, setNewBack] = useState('');

  const fetchCards = async () => {
    if (!profile?.id) return;
    const { data } = await supabase
      .from('flashcards')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: true });
    
    setCards(data || []);
    setLoading(false);
  };

  React.useEffect(() => {
    fetchCards();
  }, [profile]);

  const addCard = async () => {
    if (!newFront || !newBack || !profile) return;
    const { data, error } = await supabase
      .from('flashcards')
      .insert({
        user_id: profile.id,
        front: newFront,
        back: newBack,
        knowledge: null
      })
      .select()
      .single();

    if (data) {
      setCards([...cards, data]);
      setNewFront('');
      setNewBack('');
      setShowAdd(false);
    }
  };

  const deleteCard = async (id: string) => {
    await supabase.from('flashcards').delete().eq('id', id);
    setCards(cards.filter(c => c.id !== id));
    if (currentIndex >= cards.length - 1 && currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleKnowledge = async (type: 'hard' | 'good' | 'easy') => {
    const card = cards[currentIndex];
    await supabase.from('flashcards').update({ knowledge: type }).eq('id', card.id);
    
    const updatedCards = [...cards];
    updatedCards[currentIndex].knowledge = type;
    setCards(updatedCards);
    
    if (currentIndex === cards.length - 1) {
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#2563eb', '#7c3aed', '#db2777']
      });
    } else {
      nextCard();
    }
  };

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % cards.length);
    }, 150);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length);
    }, 150);
  };

  if (cards.length === 0 && !showAdd) {
    return (
      <div className="flex flex-col items-center justify-center p-20 bg-white rounded-[3rem] border border-dashed border-gray-300">
         <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-[2rem] flex items-center justify-center mb-6">
            <Layers className="w-10 h-10" />
         </div>
         <h2 className="text-2xl font-black mb-2 font-display">No cards yet</h2>
         <p className="text-gray-500 mb-8 max-w-xs text-center">Start building your knowledge stack by creating your first flashcard.</p>
         <button 
           onClick={() => setShowAdd(true)}
           className="px-8 py-4 gradient-bg text-white rounded-2xl font-black flex items-center gap-2 hover:scale-105 transition-transform"
         >
           <Plus className="w-5 h-5" /> Create Flashcard
         </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="flex items-center justify-between">
         <div className="space-y-1">
            <h1 className="text-3xl font-black font-display tracking-tight flex items-center gap-2">
              <Sparkles className="text-purple-600" /> Knowledge Stack
            </h1>
            <p className="text-gray-500 font-medium">Card {currentIndex + 1} of {cards.length}</p>
         </div>
         <div className="flex gap-3">
            <button 
              onClick={() => setShowAdd(true)}
              className="p-4 bg-white border border-gray-100 rounded-2xl text-blue-600 hover:bg-gray-50 transition-all shadow-sm"
            >
               <Plus className="w-6 h-6" />
            </button>
            <button 
              className="p-4 bg-white border border-gray-100 rounded-2xl text-gray-400 hover:bg-gray-50 transition-all shadow-sm"
            >
               <Layers className="w-6 h-6" />
            </button>
         </div>
      </div>

      {/* Main Flashcard */}
      <div className="perspective-1000 h-[400px] w-full relative">
         <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ x: 300, opacity: 0, rotateY: 20 }}
              animate={{ x: 0, opacity: 1, rotateY: 0 }}
              exit={{ x: -300, opacity: 0, rotateY: -20 }}
              transition={{ type: "spring", damping: 20, stiffness: 100 }}
              className="w-full h-full cursor-pointer"
              onClick={() => setIsFlipped(!isFlipped)}
            >
               <motion.div 
                 animate={{ rotateY: isFlipped ? 180 : 0 }}
                 transition={{ duration: 0.6, type: "spring", damping: 20 }}
                 className="w-full h-full relative preserve-3d"
               >
                  {/* Front */}
                  <div className={cn(
                    "absolute inset-0 backface-hidden p-12 rounded-[3.5rem] flex flex-col items-center justify-center text-center space-y-6 shadow-2xl border transition-colors",
                    isFlipped ? "pointer-events-none" : "bg-white border-blue-100"
                  )}>
                     <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
                        <HelpCircle className="w-6 h-6" />
                     </div>
                     <h2 className="text-3xl font-bold text-gray-900 leading-tight font-display">
                        {cards[currentIndex].front}
                     </h2>
                     <p className="text-xs font-black uppercase tracking-widest text-gray-400">Click to flip card</p>
                  </div>

                  {/* Back */}
                  <div className={cn(
                    "absolute inset-0 backface-hidden p-12 rounded-[3.5rem] flex flex-col items-center justify-center text-center space-y-6 shadow-2xl border bg-gradient-to-br from-blue-600 to-indigo-700 text-white rotate-y-180",
                    !isFlipped ? "pointer-events-none" : ""
                  )}>
                     <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                        <Brain className="w-6 h-6" />
                     </div>
                     <p className="text-2xl font-bold leading-relaxed">
                        {cards[currentIndex].back}
                     </p>
                     <p className="text-xs font-black uppercase tracking-widest text-white/60">Knowledge verified?</p>
                  </div>
               </motion.div>
            </motion.div>
         </AnimatePresence>
      </div>

      {/* Controls */}
      <div className="flex flex-col items-center gap-8">
         <div className="flex items-center gap-8">
            <button 
               onClick={prevCard}
               className="p-4 bg-gray-100 rounded-2xl hover:bg-gray-200 transition-all"
            >
               <ChevronLeft className="w-6 h-6" />
            </button>
            <div className="flex gap-4">
               <button 
                  onClick={() => setIsFlipped(!isFlipped)}
                  className="px-8 py-4 bg-gray-900 text-white rounded-2xl font-black flex items-center gap-2 hover:bg-black transition-all"
               >
                  <RefreshCcw className="w-5 h-5" /> Flip Card
               </button>
               <button 
                  onClick={() => deleteCard(cards[currentIndex].id)}
                  className="p-4 border border-red-100 text-red-600 rounded-2xl hover:bg-red-50 transition-all"
               >
                  <Trash2 className="w-6 h-6" />
               </button>
            </div>
            <button 
               onClick={nextCard}
               className="p-4 bg-gray-100 rounded-2xl hover:bg-gray-200 transition-all"
            >
               <ChevronRight className="w-6 h-6" />
            </button>
         </div>

         {/* Knowledge Assessment */}
         {isFlipped && (
            <motion.div 
               initial={{ y: 20, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               className="flex gap-4 p-2 bg-white rounded-3xl border shadow-xl"
            >
               <button 
                 onClick={() => handleKnowledge('hard')}
                 className="px-6 py-3 rounded-2xl text-red-600 hover:bg-red-50 transition-all flex flex-col items-center gap-1"
               >
                  <XCircle className="w-6 h-6" />
                  <span className="text-[10px] font-black uppercase tracking-tighter">Hard</span>
               </button>
               <button 
                 onClick={() => handleKnowledge('good')}
                 className="px-6 py-3 rounded-2xl text-yellow-600 hover:bg-yellow-50 transition-all flex flex-col items-center gap-1"
               >
                  <Clock className="w-6 h-6" />
                  <span className="text-[10px] font-black uppercase tracking-tighter">Good</span>
               </button>
               <button 
                 onClick={() => handleKnowledge('easy')}
                 className="px-6 py-3 rounded-2xl text-green-600 hover:bg-green-50 transition-all flex flex-col items-center gap-1"
               >
                  <CheckCircle2 className="w-6 h-6" />
                  <span className="text-[10px] font-black uppercase tracking-tighter">Easy</span>
               </button>
            </motion.div>
         )}
      </div>

      {/* Add Modal */}
      <AnimatePresence>
         {showAdd && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
               <motion.div 
                 initial={{ scale: 0.9, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 className="bg-white rounded-[2.5rem] w-full max-w-lg p-10 space-y-8 shadow-2xl"
               >
                  <h2 className="text-3xl font-black font-display tracking-tight">New Knowledge Card</h2>
                  <div className="space-y-6">
                     <div className="space-y-2">
                        <label className="text-sm font-black uppercase tracking-widest text-gray-400">Front (The Question)</label>
                        <textarea 
                           className="w-full p-6 bg-gray-50 rounded-3xl border-none outline-none focus:ring-2 ring-blue-500/20 text-lg font-bold"
                           placeholder="Type your question..."
                           rows={3}
                           value={newFront}
                           onChange={e => setNewFront(e.target.value)}
                        />
                     </div>
                     <div className="space-y-2">
                        <label className="text-sm font-black uppercase tracking-widest text-gray-400">Back (The Answer)</label>
                        <textarea 
                           className="w-full p-6 bg-gray-50 rounded-3xl border-none outline-none focus:ring-2 ring-blue-500/20 text-lg"
                           placeholder="Type the answer..."
                           rows={4}
                           value={newBack}
                           onChange={e => setNewBack(e.target.value)}
                        />
                     </div>
                  </div>
                  <div className="flex gap-4">
                     <button 
                        onClick={() => setShowAdd(false)}
                        className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl font-black hover:bg-gray-200 transition-all"
                     >
                        Cancel
                     </button>
                     <button 
                        onClick={addCard}
                        className="flex-1 py-4 gradient-bg text-white rounded-2xl font-black hover:scale-105 transition-transform"
                     >
                        Save Card
                     </button>
                  </div>
               </motion.div>
            </div>
         )}
      </AnimatePresence>
    </div>
  );
}
