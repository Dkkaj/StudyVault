import React, { useState } from 'react';
import { 
  CreditCard, 
  Check, 
  QrCode, 
  ExternalLink, 
  Send, 
  MessageCircle,
  AlertCircle,
  ShieldCheck,
  Clock,
  Loader2,
  RefreshCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { cn } from '../lib/utils';

const plans = [
  { id: '1m', duration: '1 Month', price: 99, features: ['AI Timetable', 'Exam Countdown', 'Performance Analytics', 'Dark Mode'] },
  { id: '2m', duration: '2 Months', price: 199, features: ['All 1 Month features', 'Weekly Progress Reports', 'AI Quiz Generator', 'Study Streak Rewards'] },
  { id: '6m', duration: '6 Months', price: 499, features: ['All 2 Months features', 'Export Timetable (PDF)', 'Priority Support', 'Multi-Language Support'], popular: true },
  { id: '1y', duration: '1 Year', price: 799, features: ['All 6 Months features', 'Lifetime Access to New Features', 'Personal Study Mentor', 'Custom Theme Packs'] },
];

export function Subscription() {
  const { user, profile, refreshProfile } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [utr, setUtr] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [pendingPayment, setPendingPayment] = useState<any>(null);

  const checkPending = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('payments')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    setPendingPayment(data);
  };

  React.useEffect(() => {
    checkPending();
  }, [user]);

  const handleSubscribe = (plan: any) => {
    setSelectedPlan(plan);
    setSuccess(false);
    setError('');
  };

  const handleSubmitUtr = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!utr.trim()) return;
    if (!user) return setError('You must be logged in to subscribe.');
    
    setSubmitting(true);
    setError('');

    try {
      const { error: subError } = await supabase
        .from('payments')
        .insert({
          user_id: user.id,
          plan_id: selectedPlan.id,
          amount: selectedPlan.price.toString(),
          utr_number: utr.trim(),
          status: 'pending'
        });

      if (subError) {
        if (subError.code === '23505') throw new Error('This UTR number has already been submitted.');
        throw subError;
      }
      
      setSuccess(true);
      await refreshProfile();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Submission failed. Please check your UTR and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (profile?.subscription_status === 'active') {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShieldCheck className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-bold mb-4 font-display">You are a Pro Member!</h1>
        <p className="text-gray-500 mb-8">
          Enjoy all the premium benefits of Study Vault. Your subscription is active until {profile.subscription_expires_at ? new Date(profile.subscription_expires_at).toLocaleDateString() : 'forever'}.
        </p>
        <div className="bg-white p-8 rounded-3xl border border-green-100 shadow-xl shadow-green-500/5 inline-block text-left">
          <h3 className="font-bold text-gray-900 mb-4">Plan Benefits:</h3>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {plans[2].features.map(f => (
              <li key={f} className="flex items-center gap-2 text-sm text-gray-600">
                <Check className="w-4 h-4 text-green-500" /> {f}
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  if (pendingPayment || success) {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center space-y-8">
        <div className="w-24 h-24 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto animate-pulse">
           <Clock className="w-12 h-12" />
        </div>
        <div className="space-y-2">
           <h1 className="text-3xl font-black font-display uppercase tracking-tight">Payment Verification</h1>
           <p className="text-gray-500">Your UTR/Transaction ID is currently being reviewed by the admin.</p>
        </div>
        <div className="p-10 bg-white border border-blue-100 rounded-[2.5rem] shadow-xl shadow-blue-500/5 space-y-6 text-left">
           <div className="flex items-center justify-between border-b pb-4">
              <span className="text-xs font-black uppercase text-gray-400 tracking-widest">UTR Number</span>
              <code className="text-blue-600 font-bold">{pendingPayment?.utr_number || utr}</code>
           </div>
           <div className="flex items-center justify-between border-b pb-4">
              <span className="text-xs font-black uppercase text-gray-400 tracking-widest">Plan</span>
              <span className="font-bold text-gray-900">{pendingPayment?.plan_id?.toUpperCase() || selectedPlan?.id?.toUpperCase()}</span>
           </div>
           <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase text-gray-400 tracking-widest">Status</span>
              <span className="px-3 py-1 bg-yellow-50 text-yellow-600 rounded-full text-xs font-bold uppercase tracking-widest border border-yellow-100">
                {pendingPayment?.status || 'SUBMITTED'}
              </span>
           </div>
           
           <div className="p-4 bg-blue-50 rounded-2xl text-blue-700 text-xs font-medium leading-relaxed">
              Verifying payments usually takes <strong>2-4 hours</strong>. Please check back later or contact support if it takes longer.
           </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
           <button 
             onClick={() => { refreshProfile(); checkPending(); }}
             className="px-8 py-4 bg-gray-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-black transition-all"
           >
              <RefreshCcw className="w-5 h-5" /> Refresh Status
           </button>
           <a 
              href="https://t.me/studyvaultsupport" 
              target="_blank"
              className="px-8 py-4 border-2 border-blue-100 rounded-2xl font-bold text-blue-600 hover:bg-blue-50 transition-all flex items-center justify-center gap-2"
           >
              <MessageCircle className="w-5 h-5" /> Chat Support
           </a>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold gradient-text font-display">Upgrade to Pro</h1>
        <p className="text-gray-500 max-w-xl mx-auto">
          Unlock the full potential of AI-powered studying. Choose a plan that fits your goals.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => (
          <motion.div
            key={plan.id}
            whileHover={{ y: -10 }}
            className={cn(
              "relative p-8 bg-white rounded-3xl border transition-all flex flex-col items-center text-center",
              plan.popular ? "border-blue-600 ring-4 ring-blue-500/5 shadow-xl" : "border-gray-100"
            )}
          >
            {plan.popular && (
              <span className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-600 text-white text-[10px] uppercase font-bold tracking-widest px-4 py-1 rounded-full">
                Most Popular
              </span>
            )}
            <span className="text-gray-500 font-medium mb-1">{plan.duration}</span>
            <div className="text-4xl font-black text-gray-900 mb-6">₹{plan.price}</div>
            
            <ul className="flex-1 space-y-3 text-sm text-gray-600 text-left w-full mb-8">
              {plan.features.map((feature, i) => (
                <li key={i} className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => handleSubscribe(plan)}
              className={cn(
                "w-full py-3 px-4 rounded-xl font-bold transition-all",
                plan.popular ? "gradient-bg text-white shadow-lg shadow-blue-500/20" : "bg-gray-100 text-gray-900 hover:bg-gray-200"
              )}
            >
              Get Started
            </button>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedPlan && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm"
            onClick={() => setSelectedPlan(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-[2rem] w-full max-w-lg overflow-hidden shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              {!success ? (
                <div className="p-8">
                  <div className="flex items-center justify-between mb-8">
                    <h2 className="text-2xl font-bold">Secure Payment</h2>
                    <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full font-bold text-sm">
                      {selectedPlan.duration} • ₹{selectedPlan.price}
                    </span>
                  </div>

                  <div className="text-center space-y-6">
                    <div className="relative group mx-auto w-48 h-48">
                      <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition-opacity"></div>
                      <div className="relative bg-white rounded-3xl p-4 shadow-lg flex items-center justify-center">
                        <img 
                          src="https://i.ibb.co/w3mxtwD/IMG-20260422-WA0000.webp" 
                          alt="QR Code" 
                          className="w-full h-full object-contain rounded-xl"
                        />
                      </div>
                      <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-white rounded-2xl shadow-xl flex items-center justify-center text-blue-600 border">
                        <QrCode className="w-6 h-6" />
                      </div>
                    </div>

                    <div className="space-y-2">
                        <p className="text-sm font-medium text-gray-500">Scan to pay via UPI</p>
                        <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs font-bold animate-pulse flex items-center justify-center gap-2">
                          <AlertCircle className="w-4 h-4" /> Don't pay wrong amount! Pay exactly ₹{selectedPlan.price}
                        </div>
                    </div>

                    <form onSubmit={handleSubmitUtr} className="space-y-4 pt-4 border-t">
                      <div className="text-left space-y-2">
                        <label className="text-sm font-bold text-gray-700">Enter UTR / Transaction ID</label>
                        <input 
                          type="text" 
                          placeholder="Ex: 123456789012"
                          value={utr}
                          onChange={e => setUtr(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-500 outline-none transition-all font-mono tracking-wider"
                          required
                        />
                      </div>
                      
                      {error && (
                        <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs font-bold flex items-center justify-center gap-2">
                          <AlertCircle className="w-4 h-4" /> {error}
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={submitting}
                        className="w-full py-4 rounded-xl gradient-bg text-white font-bold flex items-center justify-center gap-2 hover:shadow-xl hover:shadow-blue-500/20 active:scale-95 transition-all"
                      >
                        {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Send className="w-5 h-5" /> Submit for Approval</>}
                      </button>
                    </form>
                  </div>
                </div>
              ) : (
                <div className="p-12 text-center">
                  <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Clock className="w-10 h-10 animate-pulse" />
                  </div>
                  <h2 className="text-3xl font-bold mb-4 font-display">Under Verification!</h2>
                  <p className="text-gray-500 mb-8 leading-relaxed">
                    Thank you! Your UTR number <strong>{utr}</strong> has been submitted. 
                    Admin will verify your payment within 2-4 hours. You'll receive a notification once activated.
                  </p>
                  <button
                    onClick={() => setSelectedPlan(null)}
                    className="px-8 py-3 bg-gray-100 text-gray-900 rounded-xl font-bold hover:bg-gray-200 transition-all"
                  >
                    Got it, thanks!
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Support Section */}
      <section className="bg-white rounded-[2.5rem] p-10 border border-blue-50 shadow-sm text-center max-w-4xl mx-auto">
        <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <MessageCircle className="w-8 h-8" />
        </div>
        <h3 className="text-2xl font-bold mb-2 font-display">Need Help with Payment?</h3>
        <p className="text-gray-500 mb-8">
          Send a screenshot of your payment or UTR to our support team on Telegram for instant activation.
        </p>
        <a 
          href="https://t.me/studyvaultsupport" 
          target="_blank"
          className="inline-flex items-center gap-2 px-8 py-4 bg-[#0088cc] text-white rounded-2xl font-bold hover:scale-105 transition-all shadow-lg shadow-sky-500/20"
        >
          <ExternalLink className="w-5 h-5" />
          Chat with @studyvaultsupport
        </a>
      </section>
    </div>
  );
}

