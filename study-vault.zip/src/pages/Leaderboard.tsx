import React from 'react';
import { Trophy, Medal, Crown, Star, Flame, Target, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

const students = [
  { rank: 1, name: 'Rahul Sharma', points: 2850, streak: 45, level: 'Master', avatar: 'RS' },
  { rank: 2, name: 'Priya Patel', points: 2720, streak: 32, level: 'Expert', avatar: 'PP' },
  { rank: 3, name: 'Anish Kumar', points: 2500, streak: 28, level: 'Expert', avatar: 'AK' },
  { rank: 4, name: 'Sneha Gupta', points: 2410, streak: 15, level: 'Senior', avatar: 'SG' },
  { rank: 5, name: 'Vikram Singh', points: 2200, streak: 12, level: 'Senior', avatar: 'VS' },
  { rank: 6, name: 'Aditi Verma', points: 2150, streak: 8, level: 'Senior', avatar: 'AV' },
  { rank: 7, name: 'Rohan Mehra', points: 2000, streak: 22, level: 'Intermediate', avatar: 'RM' },
];

export function Leaderboard() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold font-display gradient-text">Global Rankings</h1>
        <p className="text-gray-500">Study hard, climb the ranks, and earn rewards.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 items-end pb-8">
        {/* Top 3 Podium */}
        <div className="order-2 md:order-1 h-fit">
          <div className="bg-white p-6 rounded-[2rem] border shadow-sm text-center relative pt-12 mt-8">
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center border-4 border-white shadow-lg text-2xl font-bold">
              PP
              <div className="absolute -bottom-2 -right-2 bg-silver p-1 bg-gray-200 rounded-lg"><Medal className="w-5 h-5 text-gray-500" /></div>
            </div>
            <h4 className="font-bold text-gray-900 mt-2">Priya Patel</h4>
            <p className="text-xs text-gray-500 mb-4">2,720 Points</p>
            <span className="text-3xl font-black text-gray-200">#2</span>
          </div>
        </div>

        <div className="order-1 md:order-2">
          <div className="bg-white p-8 rounded-[2.5rem] border-2 border-yellow-400 shadow-2xl text-center relative pt-16">
             <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-yellow-50 rounded-3xl flex items-center justify-center border-4 border-yellow-400 shadow-xl text-3xl font-bold text-yellow-600">
               RS
               <div className="absolute -top-6 -right-6 rotate-12"><Crown className="w-12 h-12 text-yellow-500 drop-shadow-md" /></div>
             </div>
             <h4 className="font-black text-xl text-gray-900 mt-4">Rahul Sharma</h4>
             <p className="text-sm font-bold text-yellow-600 mb-6 flex items-center justify-center gap-2">
               <Star className="w-4 h-4 fill-current" /> Master Level
             </p>
             <div className="p-4 bg-yellow-50 rounded-2xl">
               <span className="text-2xl font-black text-yellow-700">2,850</span>
               <span className="text-xs text-yellow-600 ml-1">pts</span>
             </div>
             <div className="text-5xl font-black text-yellow-100 mt-4">#1</div>
          </div>
        </div>

        <div className="order-3 h-fit">
           <div className="bg-white p-6 rounded-[2rem] border shadow-sm text-center relative pt-12 mt-8">
            <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center border-4 border-white shadow-lg text-2xl font-bold">
              AK
              <div className="absolute -bottom-2 -right-2 bg-bronze p-1 bg-orange-100 rounded-lg"><Medal className="w-5 h-5 text-orange-600" /></div>
            </div>
            <h4 className="font-bold text-gray-900 mt-2">Anish Kumar</h4>
            <p className="text-xs text-gray-500 mb-4">2,500 Points</p>
            <span className="text-3xl font-black text-gray-200">#3</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border shadow-sm overflow-hidden">
        <div className="p-6 border-b bg-gray-50 flex items-center justify-between">
           <h3 className="font-bold">Student Standings</h3>
           <div className="flex gap-4">
             <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-gray-400">
               <Flame className="w-3 h-3 text-orange-500" /> Streak
             </div>
             <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-gray-400">
               <Target className="w-3 h-3 text-blue-500" /> Accuracy
             </div>
           </div>
        </div>
        <div className="divide-y divide-gray-50">
          {students.map((student, i) => (
            <motion.div
              key={student.rank}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="p-5 flex items-center gap-4 hover:bg-gray-50 transition-all group"
            >
              <div className="w-8 font-black text-gray-300 text-lg group-hover:text-blue-600 transition-colors">
                #{student.rank}
              </div>
              <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center font-bold text-gray-600 shrink-0">
                {student.avatar}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-gray-900">{student.name}</h4>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest">{student.level}</span>
                  <span className="text-[10px] text-gray-400 font-medium">• {student.points} pts</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-50 rounded-xl text-orange-600 font-black">
                  <Flame className="w-4 h-4" /> {student.streak}
                </div>
                <ChevronRight className="w-5 h-5 text-gray-200" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
