import React, { useEffect, useState } from 'react';
import { 
  Trophy, 
  Flame, 
  Target, 
  Clock, 
  ChevronRight, 
  Plus, 
  Calendar as CalendarIcon,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Zap,
  Star,
  Brain,
  Layers,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  Activity
} from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { formatDate, getStatusColor, cn } from '../lib/utils';
import { Link } from 'react-router-dom';

export function Dashboard() {
  const { profile, isPremium } = useAuth();
  const [streak, setStreak] = useState(5);
  const [exams, setExams] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeNotice, setActiveNotice] = useState<any>(null);

  // New features data
  const [affirmation] = useState("Your potential is endless. Go do what you were created to do.");
  const [focusHistory] = useState([
    { id: 1, duration: '45m', subject: 'Math', time: '2h ago' },
    { id: 2, duration: '1h 20m', subject: 'English', time: 'Yesterday' }
  ]);
  const [mastery] = useState([
    { subject: 'History', progress: 85 },
    { subject: 'Science', progress: 42 }
  ]);

  useEffect(() => {
    async function fetchData() {
      if (!profile?.id) return;
      
      const { data: examData } = await supabase
        .from('exams')
        .select('*')
        .eq('user_id', profile.id)
        .order('exam_date', { ascending: true })
        .limit(3);
      
      const { data: taskData } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', profile.id)
        .eq('completed', false)
        .order('due_date', { ascending: true })
        .limit(5);

      // Fetch active notice
      const { data: noticeData } = await supabase
        .from('notices')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      setExams(examData || []);
      setTasks(taskData || []);
      setActiveNotice(noticeData);
      setLoading(false);
    }
    fetchData();
  }, [profile]);

  const stats = [
    { label: 'Study Streak', value: `${streak} Days`, icon: Flame, color: 'text-orange-500', bg: 'bg-orange-50' },
    { label: 'Focus Score', value: '780', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { label: 'Time Studied', value: '12.5h', icon: Clock, color: 'text-purple-500', bg: 'bg-purple-50' },
    { label: 'Global Rank', value: '#12', icon: Trophy, color: 'text-blue-500', bg: 'bg-blue-50' },
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-[3rem] p-10 text-white gradient-bg shadow-2xl shadow-blue-500/20">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/20 backdrop-blur-md rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/20">
              <ShieldCheck className="w-3 h-3" /> Study ID: {profile?.unique_study_id || 'XXXXXXXXXX'}
            </div>
            <div className="space-y-2">
              <h1 className="text-4xl md:text-5xl font-black font-display leading-tight tracking-tight">Study Smart, <br/>Not Hard.</h1>
              <p className="text-blue-100 max-w-lg text-lg font-medium opacity-90">
                Your AI-powered study companion is ready to help you ace your exams. 
                {isPremium ? ' Access granted to all Pro features!' : ' Upgrade to Pro to unlock AI schedules.'}
              </p>
            </div>
            <div className="flex flex-wrap gap-4 pt-2">
              <Link 
                to="/planner" 
                className="px-8 py-4 bg-white text-blue-600 rounded-2xl font-black hover:bg-blue-50 transition-all flex items-center gap-2 shadow-xl shadow-blue-900/10 active:scale-95"
              >
                <Brain className="w-5 h-5" /> Generate Plan
              </Link>
              {!isPremium && (
                <Link 
                  to="/subscription" 
                  className="px-8 py-4 bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl font-black hover:bg-white/30 transition-all flex items-center gap-2 active:scale-95"
                >
                  <Star className="w-5 h-5" /> Get Pro Pass
                </Link>
              )}
            </div>
          </div>
          <motion.div 
            animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="hidden md:block relative"
          >
             <div className="absolute inset-0 bg-white/20 blur-[60px] rounded-full"></div>
             <ShieldCheck className="w-48 h-48 text-white/20 relative z-10" />
          </motion.div>
        </div>
        
        {/* Decorative Shapes */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-white/10 rounded-full blur-[80px]"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-purple-500/20 rounded-full blur-[80px]"></div>
      </section>

      {/* Admin Notice Banner */}
      {activeNotice && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={cn(
            "p-6 rounded-3xl flex items-center justify-between gap-6 border shadow-sm",
            activeNotice.type === 'urgent' ? "bg-red-50 border-red-100" : "bg-blue-50 border-blue-100"
          )}
        >
          <div className="flex items-center gap-4">
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center",
              activeNotice.type === 'urgent' ? "bg-red-600 text-white" : "bg-blue-600 text-white shadow-lg shadow-blue-500/20"
            )}>
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className={cn("font-black text-sm", activeNotice.type === 'urgent' ? "text-red-700" : "text-blue-700")}>
                {activeNotice.title}
              </h3>
              <p className="text-gray-500 text-xs font-medium">{activeNotice.content}</p>
            </div>
          </div>
          <button 
            onClick={() => setActiveNotice(null)}
            className="p-2 hover:bg-black/5 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </motion.div>
      )}

      {/* Stats & Daily Affirmation */}
      <div className="grid lg:grid-cols-4 gap-8">
         <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="p-6 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col items-center text-center group hover:border-blue-200 hover:shadow-xl transition-all"
              >
                <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110 shadow-sm", stat.bg)}>
                  <stat.icon className={cn("w-7 h-7", stat.color)} />
                </div>
                <span className="text-2xl font-black text-gray-900 font-display">{stat.value}</span>
                <span className="text-[10px] font-black uppercase tracking-widest text-gray-400 mt-1">{stat.label}</span>
              </motion.div>
            ))}
         </div>
         <div className="lg:col-span-1">
            <div className="h-full bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[2.5rem] p-8 text-white relative overflow-hidden group shadow-xl">
               <div className="absolute top-4 right-4 opacity-20"><Sparkles /></div>
               <p className="text-[10px] font-black uppercase tracking-widest text-indigo-200 mb-4 flex items-center gap-2">
                 <Star className="w-3 h-3" /> Daily Affirmation
               </p>
               <h4 className="text-xl font-bold leading-snug italic font-serif">"{affirmation}"</h4>
               <div className="mt-6 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center"><CheckCircle2 className="w-4 h-4" /></div>
                  <span className="text-xs font-bold text-indigo-100 italic">- Your Study Mentor</span>
               </div>
            </div>
         </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column: Exams & Mastery */}
        <div className="lg:col-span-1 space-y-8">
          <section className="space-y-6">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-xl font-black font-display tracking-tight">Exam Countdown</h3>
              <Link to="/exams" className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
                <Plus className="w-4 h-4" />
              </Link>
            </div>
            <div className="space-y-4">
              {loading ? (
                [1, 2].map(i => <div key={i} className="h-24 bg-gray-100 animate-pulse rounded-[2rem]" />)
              ) : exams.length > 0 ? (
                exams.map((exam) => (
                  <div key={exam.id} className="p-6 bg-white rounded-[2rem] border border-gray-50 shadow-sm flex items-center justify-between group hover:border-blue-100 hover:shadow-lg transition-all">
                    <div className="flex items-center gap-4">
                      <div className="p-4 rounded-2xl bg-blue-50 text-blue-600 group-hover:scale-110 transition-transform">
                        <CalendarIcon className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{exam.subject_name}</h4>
                        <p className="text-xs text-gray-500 font-medium">{formatDate(exam.exam_date)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="block text-lg font-black text-blue-600 font-display leading-none">
                        {Math.ceil((new Date(exam.exam_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} 
                      </span>
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Days Left</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center bg-gray-50 rounded-[2.5rem] border border-dashed border-gray-300">
                  <AlertCircle className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm font-medium">No exams scheduled yet</p>
                </div>
              )}
            </div>
          </section>

          <section className="bg-white p-8 rounded-[2.5rem] border shadow-sm space-y-6">
             <h3 className="text-lg font-black font-display tracking-tight flex items-center gap-2">
               <Activity className="text-green-500 w-5 h-5" /> Subject Health
             </h3>
             <div className="space-y-6">
                {mastery.map(item => (
                   <div key={item.subject} className="space-y-2">
                      <div className="flex justify-between items-end">
                         <span className="text-sm font-bold text-gray-700">{item.subject}</span>
                         <span className="text-xs font-black text-green-600">{item.progress}%</span>
                      </div>
                      <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                         <motion.div 
                           initial={{ width: 0 }}
                           animate={{ width: `${item.progress}%` }}
                           transition={{ duration: 1, ease: "easeOut" }}
                           className={cn(
                             "h-full rounded-full transition-all",
                             item.progress > 70 ? "bg-green-500" : "bg-blue-500"
                           )}
                         />
                      </div>
                   </div>
                ))}
             </div>
             <button className="w-full py-3 bg-gray-50 text-gray-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-100 hover:text-gray-600 transition-all border border-dashed">
                Detailed Analysis
             </button>
          </section>
        </div>

        {/* Right Column: Tasks & Recent Focus */}
        <div className="lg:col-span-2 space-y-8">
           <section className="space-y-6">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-xl font-black font-display tracking-tight flex items-center gap-2">
                  <CheckCircle2 className="text-blue-600 w-5 h-5" /> Today's Mission
                </h3>
                <Link to="/tasks" className="text-blue-600 text-sm font-black uppercase tracking-widest hover:underline flex items-center gap-1">
                  Manager <ArrowUpRight className="w-4 h-4" />
                </Link>
              </div>
              <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
                <div className="divide-y divide-gray-100">
                  {loading ? (
                    [1, 2, 3].map(i => <div key={i} className="h-16 bg-gray-50 animate-pulse" />)
                  ) : tasks.length > 0 ? (
                    tasks.map((task) => (
                      <div key={task.id} className="p-6 flex items-center gap-5 hover:bg-gray-50 transition-all cursor-pointer group">
                        <button className="w-8 h-8 rounded-xl border-2 border-gray-100 flex items-center justify-center group-hover:border-blue-500 group-hover:bg-blue-50 transition-all shadow-sm">
                          <CheckCircle2 className="w-5 h-5 text-transparent group-hover:text-blue-500 transition-colors" />
                        </button>
                        <div className="flex-1">
                          <h4 className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors">{task.title}</h4>
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="text-[9px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 font-black uppercase tracking-widest border border-blue-100">
                              {task.subject_name}
                            </span>
                            <span className="text-[10px] text-gray-400 font-bold flex items-center gap-1">
                              <Clock className="w-3 h-3" /> {task.duration_mins} mins
                            </span>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-200 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                      </div>
                    ))
                  ) : (
                    <div className="p-16 text-center">
                      <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-sm">
                        <Trophy className="w-10 h-10" />
                      </div>
                      <h4 className="text-xl font-black text-gray-900 mb-2 font-display">Mission Accomplished!</h4>
                      <p className="text-gray-500 text-sm max-w-xs mx-auto font-medium">
                        Your task list is clear. Reward yourself with a break or prep for tomorrow.
                      </p>
                    </div>
                  )}
                </div>
                {tasks.length > 0 && (
                  <div className="p-5 bg-gray-50/50 text-center border-t border-gray-100">
                    <button className="text-blue-600 text-xs font-black uppercase tracking-widest flex items-center gap-2 mx-auto hover:scale-105 transition-transform">
                      <Plus className="w-4 h-4" /> Add Extra Task
                    </button>
                  </div>
                )}
              </div>
           </section>

           <section className="grid md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-[2.5rem] border shadow-sm space-y-6">
                 <h4 className="font-black font-display flex items-center gap-2 text-gray-900">
                    <TrendingUp className="text-blue-600 w-5 h-5" /> Recent Focus
                 </h4>
                 <div className="space-y-4">
                    {focusHistory.map(item => (
                       <div key={item.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-transparent hover:border-blue-100 transition-all">
                          <div className="flex items-center gap-3">
                             <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-blue-600 shadow-sm"><Zap className="w-5 h-5" /></div>
                             <div>
                                <p className="text-sm font-bold text-gray-900">{item.duration}</p>
                                <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{item.subject}</p>
                             </div>
                          </div>
                          <span className="text-[10px] text-gray-400 font-bold">{item.time}</span>
                       </div>
                    ))}
                 </div>
              </div>

              <div className="bg-white p-8 rounded-[2.5rem] border shadow-sm flex flex-col items-center justify-center text-center space-y-4 relative overflow-hidden">
                 <div className="absolute -bottom-6 -right-6 opacity-5"><Layers className="w-32 h-32" /></div>
                 <div className="w-16 h-16 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center shadow-sm">
                    <Layers className="w-8 h-8" />
                 </div>
                 <div>
                    <h4 className="text-lg font-black font-display text-gray-900">Flashcard Stacks</h4>
                    <p className="text-xs text-gray-500 font-medium">85 Cards reviewed this week</p>
                 </div>
                 <Link to="/flashcards" className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-all">
                    Practice Now
                 </Link>
              </div>
           </section>
        </div>
      </div>
    </div>
  );
}
