import React, { useState, useEffect } from 'react';
import { 
  Users, 
  CreditCard, 
  CheckCircle2, 
  XCircle, 
  BarChart3, 
  MoreHorizontal, 
  Filter, 
  RefreshCcw,
  Ban,
  ShieldCheck,
  Search,
  BellRing,
  Trash2,
  UserCheck,
  AlertCircle,
  Megaphone,
  FileBox,
  Plus,
  Save,
  Download,
  ExternalLink,
  Package,
  Globe,
  Link as LinkIcon,
  LogOut
} from 'lucide-react';
import { motion } from 'motion/react';
import { supabase } from '../lib/supabase';
import { cn, formatDate } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';

export function AdminPanel() {
  const { isAdmin, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'users' | 'payments' | 'stats' | 'notices' | 'assets' | 'resources'>('payments');
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [notices, setNotices] = useState<any[]>([]);
  const [assets, setAssets] = useState<any[]>([]);
  const [publicResources, setPublicResources] = useState<any[]>([]);
  const [stats, setStats] = useState({ totalRevenue: 0, activeSubscriptions: 0, pendingRequests: 0, totalUsers: 0 });
  const [dbStatus, setDbStatus] = useState<{ table: string; exists: boolean }[]>([]);

  // Create forms state
  const [showNoticeForm, setShowNoticeForm] = useState(false);
  const [noticeForm, setNoticeForm] = useState({ title: '', content: '', type: 'info' });
  const [showAssetForm, setShowAssetForm] = useState(false);
  const [assetForm, setAssetForm] = useState({ name: '', url: '', file_type: 'apk', version: '', description: '' });
  const [showResourceForm, setShowResourceForm] = useState(false);
  const [resourceForm, setResourceForm] = useState({ title: '', url: '', type: 'Link', is_public: true });
  const [searchTerm, setSearchTerm] = useState('');

  const checkDb = async () => {
    const tables = ['users', 'payments', 'exams', 'tasks', 'study_plans', 'flashcards', 'notes', 'bookmarks', 'notices', 'assets'];
    const results = [];
    for (const table of tables) {
      const { error } = await supabase.from(table).select('id').limit(1);
      results.push({ 
        table, 
        exists: !error || (error.code !== 'PGRST116' && error.message?.includes('schema cache') === false)
      });
    }
    setDbStatus(results);
  };

  const fetchData = async () => {
    setLoading(true);
    if (!isAdmin) return;

    await checkDb();
    
    try {
      // Fetch payments
      if (activeTab === 'payments') {
        // We use a robust select that handles the relationship carefully
        const { data: payments, error: payError } = await supabase
          .from('payments')
          .select(`
            *,
            users (
              full_name,
              email,
              unique_study_id
            )
          `)
          .order('created_at', { ascending: false });
        
        if (payError) {
          console.error("Payments fetch error:", payError);
          // Fallback: Try fetching without the join if it failed
          const { data: simplePayments } = await supabase
            .from('payments')
            .select('*')
            .order('created_at', { ascending: false });
          setData(simplePayments || []);
        } else {
          setData(payments || []);
        }
      }

      // Fetch users
      if (activeTab === 'users') {
        const { data: userData } = await supabase
          .from('users')
          .select('*')
          .order('created_at', { ascending: false });
        setUsers(userData || []);
      }

      // Fetch notices
      if (activeTab === 'notices') {
        const { data: NoticeData } = await supabase
          .from('notices')
          .select('*')
          .order('created_at', { ascending: false });
        setNotices(NoticeData || []);
      }

      // Fetch assets
      if (activeTab === 'assets') {
        const { data: assetData } = await supabase
          .from('assets')
          .select('*')
          .order('created_at', { ascending: false });
        setAssets(assetData || []);
      }

      // Fetch public resources
      if (activeTab === 'resources') {
        const { data: resData } = await supabase
          .from('bookmarks')
          .select('*')
          .eq('is_public', true)
          .order('created_at', { ascending: false });
        setPublicResources(resData || []);
      }

      // Fetch stats
      const { data: allUsers } = await supabase.from('users').select('id, subscription_status');
      const { data: allPayments } = await supabase.from('payments').select('amount').eq('status', 'approved');
      
      const revenue = allPayments?.reduce((sum, p) => sum + parseInt(p.amount.replace(/[^0-9]/g, '') || '0'), 0) || 0;
      const active = allUsers?.filter(u => u.subscription_status === 'active').length || 0;
      const { data: pendingData } = await supabase.from('payments').select('id').eq('status', 'pending');
      const pending = pendingData?.length || 0;

      setStats({
        totalRevenue: revenue,
        activeSubscriptions: active,
        pendingRequests: pending,
        totalUsers: allUsers?.length || 0
      });
    } catch (err) {
      console.error("Fetch data error:", err);
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeTab, isAdmin]);

  const handleApprove = async (payment: any) => {
    try {
      const expiresAt = new Date();
      switch (payment.plan_id) {
        case '1m': expiresAt.setMonth(expiresAt.getMonth() + 1); break;
        case '2m': expiresAt.setMonth(expiresAt.getMonth() + 2); break;
        case '6m': expiresAt.setMonth(expiresAt.getMonth() + 6); break;
        case '1y': expiresAt.setFullYear(expiresAt.getFullYear() + 1); break;
        default: expiresAt.setMonth(expiresAt.getMonth() + 1);
      }

      await supabase.from('payments').update({ status: 'approved' }).eq('id', payment.id);
      await supabase.from('users').update({ 
        subscription_status: 'active',
        subscription_type: payment.plan_id,
        subscription_expires_at: expiresAt.toISOString()
      }).eq('id', payment.user_id);

      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const manualSubscribe = async (userId: string, plan: string) => {
    try {
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + (plan === '1y' ? 12 : 1));
      await supabase.from('users').update({ 
        subscription_status: 'active',
        subscription_type: plan,
        subscription_expires_at: expiresAt.toISOString()
      }).eq('id', userId);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const createNotice = async () => {
    if (!noticeForm.title || !noticeForm.content) return;
    try {
      await supabase.from('notices').insert([noticeForm]);
      setNoticeForm({ title: '', content: '', type: 'info' });
      setShowNoticeForm(false);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const createAsset = async () => {
    if (!assetForm.name || !assetForm.url) return;
    try {
      await supabase.from('assets').insert([assetForm]);
      setAssetForm({ name: '', url: '', file_type: 'apk', version: '', description: '' });
      setShowAssetForm(false);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const createResource = async () => {
    if (!resourceForm.title || !resourceForm.url || !profile?.id) return;
    try {
      await supabase.from('bookmarks').insert([{ ...resourceForm, user_id: profile.id }]);
      setResourceForm({ title: '', url: '', type: 'Link', is_public: true });
      setShowResourceForm(false);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const toggleUserStatus = async (user: any) => {
    try {
      await supabase.from('users').update({ is_active: !user.is_active }).eq('id', user.id);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const deleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to PERMANENTLY delete this user?')) return;
    try {
      await supabase.from('users').delete().eq('id', userId);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const deleteNotice = async (id: string) => {
    await supabase.from('notices').delete().eq('id', id);
    fetchData();
  };

  const deleteAsset = async (id: string) => {
    await supabase.from('assets').delete().eq('id', id);
    fetchData();
  };

  const handleReject = async (paymentId: string) => {
    await supabase.from('payments').update({ status: 'rejected' }).eq('id', paymentId);
    fetchData();
  };

  if (!isAdmin) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto">
             <ShieldCheck className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold">Access Denied</h1>
          <p className="text-gray-500">Only authorized administrators can access this panel.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display">Command Center</h1>
          <p className="text-gray-500">Manage Study Vault platform and users</p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={fetchData} className="p-2 rounded-xl bg-white border hover:bg-gray-50 transition-all">
            <RefreshCcw className={cn("w-5 h-5 text-gray-600", loading && "animate-spin")} />
          </button>
          <button 
            onClick={() => supabase.auth.signOut()}
            className="p-2 rounded-xl bg-red-50 border border-red-100 text-red-600 hover:bg-red-600 hover:text-white transition-all group"
            title="Log Out"
          >
            <LogOut className="w-5 h-5" />
          </button>
          <button className="px-6 py-2.5 gradient-bg text-white rounded-xl font-bold flex items-center gap-2">
            <BellRing className="w-5 h-5" /> Broadcast msg
          </button>
        </div>
      </div>

      {/* Stats Board */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="p-6 bg-white rounded-3xl border shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-green-50 text-green-600 flex items-center justify-center">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Revenue</p>
              <p className="text-2xl font-black">₹{stats.totalRevenue}</p>
            </div>
          </div>
          <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-green-500 w-[60%]"></div>
          </div>
        </div>
        <div className="p-6 bg-white rounded-3xl border shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Active Pro</p>
              <p className="text-2xl font-black">{stats.activeSubscriptions}</p>
            </div>
          </div>
          <p className="text-xs text-blue-600 font-bold">{(stats.activeSubscriptions/stats.totalUsers * 100).toFixed(1)}% Conversion rate</p>
        </div>
        <div className="p-6 bg-white rounded-3xl border shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-yellow-50 text-yellow-600 flex items-center justify-center">
              <RefreshCcw className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Pending Approvals</p>
              <p className="text-2xl font-black">{stats.pendingRequests}</p>
            </div>
          </div>
          <p className="text-xs text-yellow-600 font-bold">Avg. handle time: 1.5h</p>
        </div>
        <div className="p-6 bg-white rounded-3xl border shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Users</p>
              <p className="text-2xl font-black">{stats.totalUsers}</p>
            </div>
          </div>
          <p className="text-xs text-purple-600 font-bold">Growing +12% this week</p>
        </div>
      </div>

      {/* Database Health Check */}
      {dbStatus.some(s => !s.exists) && (
        <div className="bg-red-50 border border-red-100 p-8 rounded-[2.5rem] space-y-6">
           <div className="flex items-center gap-4 text-red-600">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                 <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                 <h3 className="text-xl font-bold">Database Setup Required</h3>
                 <p className="text-sm font-medium opacity-80">Some required tables were not found in your Supabase project.</p>
              </div>
           </div>
           
           <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {dbStatus.map(s => (
                <div key={s.table} className={cn(
                  "p-4 rounded-2xl border flex items-center justify-between",
                  s.exists ? "bg-green-50/50 border-green-100 text-green-700" : "bg-white border-red-200 text-red-600 shadow-sm"
                )}>
                  <span className="text-xs font-bold font-mono">{s.table}</span>
                  {s.exists ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                </div>
              ))}
           </div>

           <div className="p-6 bg-white rounded-3xl border border-red-100 space-y-4">
              <p className="text-sm font-bold text-gray-900">How to fix this:</p>
              <ol className="text-sm text-gray-500 space-y-2 list-decimal ml-4 font-medium">
                 <li>Open your <strong>Supabase Dashboard</strong>.</li>
                 <li>Navigate to the <strong>SQL Editor</strong>.</li>
                 <li>Copy the contents of <code>supabase_schema.sql</code> (provided by AI).</li>
                 <li>Paste and <strong>Run</strong> the query.</li>
                 <li>Refresh this page.</li>
              </ol>
           </div>
        </div>
      )}

      {/* Main Panel */}
      <div className="bg-white rounded-[2rem] border shadow-sm overflow-hidden">
        <div className="flex items-center border-b px-6">
          <button 
            onClick={() => setActiveTab('payments')}
            className={cn("px-6 py-4 font-bold text-sm transition-all border-b-2", activeTab === 'payments' ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500")}
          >
            Payments & Requests
          </button>
          <button 
            onClick={() => setActiveTab('users')}
            className={cn("px-6 py-4 font-bold text-sm transition-all border-b-2", activeTab === 'users' ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500")}
          >
            User Management
          </button>
          <button 
            onClick={() => setActiveTab('notices')}
            className={cn("px-6 py-4 font-bold text-sm transition-all border-b-2", activeTab === 'notices' ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500")}
          >
            Notices & Alerts
          </button>
          <button 
            onClick={() => setActiveTab('assets')}
            className={cn("px-6 py-4 font-bold text-sm transition-all border-b-2", activeTab === 'assets' ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500")}
          >
            App/Asset Lib
          </button>
          <button 
            onClick={() => setActiveTab('resources')}
            className={cn("px-6 py-4 font-bold text-sm transition-all border-b-2", activeTab === 'resources' ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500")}
          >
            Shared Library
          </button>
          <div className="flex-1"></div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-1.5 bg-gray-100 rounded-lg text-xs outline-none focus:ring-1 focus:ring-blue-500 transition-all border border-transparent"
            />
          </div>
        </div>

        <div className="overflow-x-auto p-6">
          {activeTab === 'payments' && (
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Student</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Plan / Amount</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">UTR Number</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {data.filter(p => {
                  const student = Array.isArray(p.users) ? p.users[0] : p.users;
                  if (!searchTerm) return true;
                  const search = searchTerm.toLowerCase();
                  return (
                    student?.full_name?.toLowerCase().includes(search) ||
                    student?.email?.toLowerCase().includes(search) ||
                    (p.utr_number && p.utr_number.toLowerCase().includes(search)) ||
                    p.plan_id?.toLowerCase().includes(search)
                  );
                }).length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-20 text-center">
                      <div className="flex flex-col items-center gap-4">
                        <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center text-gray-300">
                          <CheckCircle2 className="w-8 h-8" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">All caught up!</p>
                          <p className="text-xs text-gray-400">No pending payment requests were found.</p>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
                {data.filter(p => {
                  const student = Array.isArray(p.users) ? p.users[0] : p.users;
                  if (!searchTerm) return true;
                  const search = searchTerm.toLowerCase();
                  return (
                    student?.full_name?.toLowerCase().includes(search) ||
                    student?.email?.toLowerCase().includes(search) ||
                    (p.utr_number && p.utr_number.toLowerCase().includes(search)) ||
                    p.plan_id?.toLowerCase().includes(search)
                  );
                }).map((payment) => {
                  const student = Array.isArray(payment.users) ? payment.users[0] : payment.users;
                  return (
                    <tr key={payment.id} className="hover:bg-gray-50 transition-all border-l-4 border-transparent hover:border-blue-500">
                      <td className="px-6 py-6">
                        <div className="flex items-center gap-3">
                           <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center font-black text-gray-400">
                              {student?.full_name?.charAt(0) || 'S'}
                           </div>
                           <div>
                              <div className="font-bold text-gray-900">{student?.full_name || 'Anonymous Student'}</div>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{student?.email}</span>
                                <span className="px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded text-[9px] font-black">{student?.unique_study_id || 'NO_ID'}</span>
                              </div>
                           </div>
                        </div>
                      </td>
                    <td className="px-6 py-6">
                      <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{payment.plan_id} Access</div>
                      <div className="text-xl font-black text-blue-600">₹{payment.amount}</div>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">UTR / TRANS ID</span>
                        <div className="flex items-center gap-2">
                          <code className="text-base bg-blue-600 text-white px-4 py-2 rounded-xl font-mono font-black border-2 border-blue-400 block w-full shadow-lg shadow-blue-500/20">
                            {payment.utr_number || 'NULL_UTR'}
                          </code>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6 text-xs text-gray-500 font-medium">
                      {new Date(payment.created_at).toLocaleDateString()}<br/>
                      <span className="text-[10px] opacity-50">{new Date(payment.created_at).toLocaleTimeString()}</span>
                    </td>
                    <td className="px-6 py-6 text-right">
                      {payment.status === 'pending' ? (
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleApprove(payment)}
                            className="px-4 py-2 bg-green-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-green-700 transition-all shadow-lg shadow-green-500/20 flex items-center gap-2"
                          >
                            <CheckCircle2 className="w-4 h-4" /> Approve
                          </button>
                          <button 
                            onClick={() => handleReject(payment.id)}
                            className="px-4 py-2 bg-red-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg shadow-red-500/20 flex items-center gap-2"
                          >
                            <XCircle className="w-4 h-4" /> Reject
                          </button>
                        </div>
                      ) : (
                        <div className="text-right space-y-1">
                           <span className={cn("px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border border-current", 
                             payment.status === 'approved' ? "text-green-600 bg-green-50" : "text-red-500 bg-red-50"
                           )}>
                             {payment.status}
                           </span>
                        </div>
                      )}
                    </td>
                  </tr>
                ); })}
              </tbody>
            </table>
          )}

          {activeTab === 'users' && (
            <table className="w-full text-left">
               <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Study ID</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">User Details</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Subscription</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {users.map((u) => (
                  <tr key={u.id} className={cn("hover:bg-gray-50 transition-all", !u.is_active && "bg-red-50/30")}>
                    <td className="px-6 py-4">
                      <code className="text-xs font-black text-blue-600 bg-blue-50 px-2 py-1 rounded">
                        {u.unique_study_id || 'Generating...'}
                      </code>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-bold flex items-center gap-2">
                        {u.full_name} 
                        {u.role === 'admin' && <ShieldCheck className="w-3 h-3 text-purple-600" />}
                        {!u.is_active && <Ban className="w-3 h-3 text-red-500" />}
                      </div>
                      <div className="text-xs text-gray-400">{u.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-1">
                        <span className={cn("px-3 py-1 rounded-full text-[10px] font-bold uppercase border w-max", 
                          u.subscription_status === 'active' ? "bg-blue-50 text-blue-600 border-blue-100" : "bg-gray-100 text-gray-600 border-gray-200"
                        )}>
                          {u.subscription_status}
                        </span>
                        <div className="flex gap-1">
                          <button onClick={() => manualSubscribe(u.id, '1m')} className="text-[9px] font-bold text-blue-600 hover:underline">Add 1M</button>
                          <button onClick={() => manualSubscribe(u.id, '1y')} className="text-[9px] font-bold text-purple-600 hover:underline">Add 1Y</button>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs">
                      {u.is_active ? (
                        <span className="text-green-600 font-bold flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Active</span>
                      ) : (
                        <span className="text-red-600 font-bold flex items-center gap-1"><Ban className="w-3 h-3" /> Disabled</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={() => toggleUserStatus(u)}
                          title={u.is_active ? "Deactivate Account" : "Activate Account"}
                          className={cn(
                            "p-2 rounded-lg transition-all",
                            u.is_active ? "text-gray-400 hover:text-yellow-600 hover:bg-yellow-50" : "text-green-600 bg-green-50 hover:bg-green-100"
                          )}
                        >
                          {u.is_active ? <Ban className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                        </button>
                        <button 
                          onClick={() => deleteUser(u.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeTab === 'notices' && (
            <div className="space-y-6">
               <div className="flex items-center justify-between">
                  <h3 className="font-bold flex items-center gap-2"><Megaphone className="w-5 h-5 text-blue-600" /> Platform Announcements</h3>
                  <button 
                    onClick={() => setShowNoticeForm(!showNoticeForm)}
                    className="px-4 py-2 bg-gray-900 text-white rounded-xl text-xs font-bold flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> New Notice
                  </button>
               </div>

               {showNoticeForm && (
                 <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100 space-y-4">
                    <input 
                      type="text" 
                      placeholder="Title" 
                      value={noticeForm.title}
                      onChange={e => setNoticeForm({...noticeForm, title: e.target.value})}
                      className="w-full bg-white border rounded-xl px-4 py-2 text-sm outline-none" 
                    />
                    <textarea 
                      placeholder="Content (Markdown supported)" 
                      value={noticeForm.content}
                      onChange={e => setNoticeForm({...noticeForm, content: e.target.value})}
                      className="w-full bg-white border rounded-xl px-4 py-2 text-sm outline-none h-24"
                    />
                    <div className="flex items-center justify-between">
                       <select 
                         value={noticeForm.type}
                         onChange={e => setNoticeForm({...noticeForm, type: e.target.value})}
                         className="bg-white border rounded-lg px-3 py-1.5 text-xs font-bold"
                       >
                          <option value="info">Info</option>
                          <option value="warning">Warning</option>
                          <option value="urgent">Urgent</option>
                       </select>
                       <button onClick={createNotice} className="px-6 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold flex items-center gap-2">
                          <Save className="w-4 h-4" /> Post Announcement
                       </button>
                    </div>
                 </div>
               )}

               <div className="space-y-4">
                  {notices.map(notice => (
                    <div key={notice.id} className="p-6 bg-white border rounded-3xl flex items-start justify-between group">
                       <div className="space-y-2">
                          <div className="flex items-center gap-2">
                             <span className={cn("px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest", 
                               notice.type === 'urgent' ? "bg-red-100 text-red-600" : "bg-blue-100 text-blue-600"
                             )}>{notice.type}</span>
                             <h4 className="font-bold">{notice.title}</h4>
                          </div>
                          <p className="text-sm text-gray-500">{notice.content}</p>
                          <p className="text-[10px] text-gray-400 font-medium">Published: {formatDate(notice.created_at)}</p>
                       </div>
                       <button onClick={() => deleteNotice(notice.id)} className="p-3 text-gray-400 hover:bg-red-50 hover:text-red-600 rounded-2xl opacity-0 group-hover:opacity-100 transition-all">
                          <Trash2 className="w-5 h-5" />
                       </button>
                    </div>
                  ))}
                  {notices.length === 0 && <div className="text-center py-10 text-gray-400 italic">No announcements posted yet.</div>}
               </div>
            </div>
          )}

          {activeTab === 'assets' && (
            <div className="space-y-6">
               <div className="flex items-center justify-between">
                  <h3 className="font-bold flex items-center gap-2"><FileBox className="w-5 h-5 text-purple-600" /> Platform Assets (.apk, .pdf)</h3>
                  <button 
                    onClick={() => setShowAssetForm(!showAssetForm)}
                    className="px-4 py-2 bg-gray-900 text-white rounded-xl text-xs font-bold flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Link New Asset
                  </button>
               </div>

               {showAssetForm && (
                 <div className="p-6 bg-purple-50 rounded-3xl border border-purple-100 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-2 col-span-2">
                          <label className="text-sm font-bold">Asset Name</label>
                          <input type="text" placeholder="e.g. Study Vault Android v1.0" value={assetForm.name} onChange={e => setAssetForm({...assetForm, name: e.target.value})} className="w-full bg-white border rounded-xl px-4 py-2 text-sm outline-none" />
                       </div>
                       <div className="space-y-2 flex-1">
                          <label className="text-sm font-bold">URL / Hosting Link</label>
                          <input type="text" placeholder="https://..." value={assetForm.url} onChange={e => setAssetForm({...assetForm, url: e.target.value})} className="w-full bg-white border rounded-xl px-4 py-2 text-sm outline-none" />
                       </div>
                       <div className="space-y-2">
                          <label className="text-sm font-bold">Type</label>
                          <select value={assetForm.file_type} onChange={e => setAssetForm({...assetForm, file_type: e.target.value})} className="w-full bg-white border rounded-xl px-4 py-2 text-sm font-bold">
                             <option value="apk">APK (App)</option>
                             <option value="pdf">PDF (Document)</option>
                             <option value="image">Image</option>
                             <option value="other">Other</option>
                          </select>
                       </div>
                    </div>
                    <button onClick={createAsset} className="w-full py-4 bg-purple-600 text-white rounded-2xl font-black flex items-center justify-center gap-2">
                       <Plus className="w-5 h-5" /> Register Asset
                    </button>
                 </div>
               )}

               <div className="grid sm:grid-cols-2 gap-6">
                  {assets.map(asset => (
                    <div key={asset.id} className="p-6 bg-white border rounded-[2.5rem] flex items-center justify-between group">
                       <div className="flex items-center gap-4">
                          <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-500 shadow-sm border group-hover:bg-purple-100 group-hover:text-purple-600 transition-colors">
                             {asset.file_type === 'apk' ? <Package className="w-7 h-7" /> : <FileBox className="w-7 h-7" />}
                          </div>
                          <div>
                             <h4 className="font-bold flex items-center gap-2">{asset.name} <span className="text-[10px] bg-gray-100 px-1.5 py-0.5 rounded uppercase font-black tracking-widest">{asset.file_type}</span></h4>
                             <p className="text-xs text-gray-500 truncate max-w-[150px]">{asset.url}</p>
                          </div>
                       </div>
                       <div className="flex gap-2">
                          <a href={asset.url} target="_blank" rel="noreferrer" className="p-3 bg-gray-50 text-gray-900 rounded-2xl hover:bg-gray-100"><ExternalLink className="w-4 h-4" /></a>
                          <button onClick={() => deleteAsset(asset.id)} className="p-3 text-red-500 hover:bg-red-50 rounded-2xl"><Trash2 className="w-4 h-4" /></button>
                       </div>
                    </div>
                  ))}
                  {assets.length === 0 && <div className="col-span-2 text-center py-10 text-gray-400 italic">No assets or files registered.</div>}
               </div>
            </div>
          )}

          {activeTab === 'resources' && (
            <div className="space-y-6">
               <div className="flex items-center justify-between">
                  <h3 className="font-bold flex items-center gap-2"><Globe className="w-5 h-5 text-green-600" /> Platform Shared Library</h3>
                  <button 
                    onClick={() => setShowResourceForm(!showResourceForm)}
                    className="px-4 py-2 bg-gray-900 text-white rounded-xl text-xs font-bold flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Add Shared Link
                  </button>
               </div>

               {showResourceForm && (
                 <div className="p-6 bg-green-50 rounded-3xl border border-green-100 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                       <input type="text" placeholder="Resource Title" value={resourceForm.title} onChange={e => setResourceForm({...resourceForm, title: e.target.value})} className="w-full bg-white border rounded-xl px-4 py-2 text-sm outline-none" />
                       <input type="text" placeholder="Resource URL (https://...)" value={resourceForm.url} onChange={e => setResourceForm({...resourceForm, url: e.target.value})} className="w-full bg-white border rounded-xl px-4 py-2 text-sm outline-none" />
                    </div>
                    <button onClick={createResource} className="w-full py-4 bg-green-600 text-white rounded-2xl font-black flex items-center justify-center gap-2 shadow-lg shadow-green-500/20">
                       <Save className="w-5 h-5" /> Save to Public Library
                    </button>
                 </div>
               )}

               <div className="grid gap-4">
                  {publicResources.map(res => (
                    <div key={res.id} className="p-5 bg-white border rounded-[2rem] flex items-center justify-between group hover:shadow-md transition-all">
                       <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center border border-green-100">
                             <LinkIcon className="w-6 h-6" />
                          </div>
                          <div>
                             <h4 className="font-bold">{res.title}</h4>
                             <p className="text-xs text-gray-500 truncate max-w-[300px]">{res.url}</p>
                          </div>
                       </div>
                       <div className="flex gap-2">
                          <a href={res.url} target="_blank" rel="noreferrer" className="p-3 bg-gray-50 text-gray-900 rounded-2xl hover:bg-gray-100"><ExternalLink className="w-4 h-4" /></a>
                          <button onClick={async () => {
                             await supabase.from('bookmarks').delete().eq('id', res.id);
                             fetchData();
                          }} className="p-3 text-red-500 hover:bg-red-50 rounded-2xl transition-all"><Trash2 className="w-4 h-4" /></button>
                       </div>
                    </div>
                  ))}
                  {publicResources.length === 0 && <div className="text-center py-10 text-gray-400 italic">Public library is currently empty.</div>}
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
