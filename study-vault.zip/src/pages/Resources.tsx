import React, { useState } from 'react';
import { 
  FileText, 
  Link as LinkIcon, 
  Bookmark, 
  Search, 
  Plus, 
  ExternalLink, 
  Trash2, 
  Globe, 
  File,
  Calculator,
  Mic,
  Users as UsersIcon,
  Award,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { cn } from '../lib/utils';

export function Resources() {
  const { profile } = useAuth();
  const [activeCategory, setActiveCategory] = useState<'bookmarks' | 'buddy' | 'calc' | 'voice'>('bookmarks');
  
  const [links, setLinks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLinks = async () => {
    try {
      // Get private links
      const { data: userData } = await supabase
        .from('bookmarks')
        .select('*')
        .eq('user_id', profile?.id || '')
        .eq('is_public', false)
        .order('created_at', { ascending: false });
      
      // Get public links (added by admin)
      const { data: publicData } = await supabase
        .from('bookmarks')
        .select('*')
        .eq('is_public', true)
        .order('created_at', { ascending: false });
      
      setLinks([...(publicData || []), ...(userData || [])]);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchLinks();
  }, [profile]);

  const [scores, setScores] = useState({ math: '', science: '', english: '', history: '' });
  const [cgpa, setCgpa] = useState<number | null>(null);

  const [buddyRequests, setBuddyRequests] = useState<string[]>([]);
  const [isGeneratingVoice, setIsGeneratingVoice] = useState(false);

  const calculateCgpa = () => {
    const vals = Object.values(scores).map(v => parseFloat(v)).filter(v => !isNaN(v));
    if (vals.length === 0) return;
    const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
    setCgpa(parseFloat(avg.toFixed(2)));
  };

  const handleBuddyRequest = (id: number) => {
    if (buddyRequests.includes(id.toString())) return;
    setBuddyRequests([...buddyRequests, id.toString()]);
    alert(`Buddy request sent to Student #${id}34! They will receive a notification.`);
  };

  const handleVoiceGenerate = () => {
    setIsGeneratingVoice(true);
    setTimeout(() => {
      setIsGeneratingVoice(false);
      alert('AI Audio Session generated and added to your playlist!');
    }, 2000);
  };

  const handleAddLink = async () => {
    const title = prompt('Enter resource title:');
    const url = prompt('Enter resource URL:');
    if (title && url && profile) {
      const { data } = await supabase
        .from('bookmarks')
        .insert({
          user_id: profile.id,
          title,
          url,
          type: 'Link'
        })
        .select()
        .single();
      
      if (data) setLinks([data, ...links]);
    }
  };

  const handleDeleteLink = async (id: string) => {
    await supabase.from('bookmarks').delete().eq('id', id);
    setLinks(links.filter(l => l.id !== id));
  };

  const categories = [
    { id: 'bookmarks', label: 'Resource Hub', icon: Bookmark, color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 'buddy', label: 'Study Buddies', icon: UsersIcon, color: 'text-purple-600', bg: 'bg-purple-50' },
    { id: 'calc', label: 'CGPA Predictor', icon: Calculator, color: 'text-green-600', bg: 'bg-green-50' },
    { id: 'voice', label: 'AI Voice Reader', icon: Mic, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
         <div className="space-y-1">
            <h1 className="text-4xl font-black font-display tracking-tight">Tools & Resources</h1>
            <p className="text-gray-500 font-medium">Everything you need to supercharge your study sessions.</p>
         </div>
         <div className="flex bg-white p-1.5 rounded-[2rem] border shadow-sm w-full md:w-auto">
            {categories.map((cat) => (
              <button 
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={cn(
                  "flex-1 md:flex-none px-6 py-3 rounded-2xl text-sm font-bold transition-all flex items-center justify-center gap-2",
                  activeCategory === cat.id ? "bg-gray-900 text-white shadow-lg" : "text-gray-500 hover:text-gray-900"
                )}
              >
                <cat.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{cat.label}</span>
              </button>
            ))}
         </div>
      </div>

      <AnimatePresence mode="wait">
        {activeCategory === 'bookmarks' && (
          <motion.div 
            key="bookmarks"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="grid md:grid-cols-3 gap-8"
          >
            <div className="md:col-span-2 space-y-6">
               <div className="bg-white p-8 rounded-[2.5rem] border shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                     <h3 className="text-xl font-bold flex items-center gap-2"><Globe className="text-blue-600" /> Bookmarked Links</h3>
                     <button 
                       onClick={handleAddLink}
                       className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-blue-100 transition-all">
                        <Plus className="w-4 h-4" /> Add Link
                     </button>
                  </div>
                   <div className="grid gap-4">
                      {links.map(link => (
                         <div key={link.id} className="p-5 bg-gray-50 rounded-3xl border border-transparent hover:border-blue-100 hover:bg-white transition-all flex items-center justify-between group">
                            <div className="flex items-center gap-4">
                               <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm">
                                  <LinkIcon className="w-6 h-6" />
                               </div>
                               <div>
                                  <h4 className="font-bold text-gray-900 flex items-center gap-2">
                                     {link.title}
                                     {link.is_public && <span className="text-[9px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded-full font-black uppercase tracking-tight">Official</span>}
                                  </h4>
                                  <p className="text-xs text-gray-500">{link.url}</p>
                               </div>
                            </div>
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                               <a href={link.url} target="_blank" rel="noreferrer" className="p-2 text-gray-400 hover:text-blue-600 rounded-lg"><ExternalLink className="w-4 h-4" /></a>
                               {!link.is_public && (
                                 <button 
                                   onClick={() => handleDeleteLink(link.id)}
                                   className="p-2 text-gray-400 hover:text-red-600 rounded-lg"
                                 >
                                   <Trash2 className="w-4 h-4" />
                                 </button>
                               )}
                            </div>
                         </div>
                      ))}
                   </div>
               </div>
            </div>
            <div className="md:col-span-1 space-y-6">
               <div className="bg-white p-8 rounded-[2.5rem] border shadow-sm space-y-6">
                  <h3 className="font-bold flex items-center gap-2"><Award className="text-yellow-600" /> Achievement Hall</h3>
                  <div className="grid grid-cols-3 gap-4">
                     {[1, 2, 3, 4, 5, 6].map(i => (
                        <div key={i} className={cn(
                          "aspect-square rounded-2xl border flex items-center justify-center transition-all",
                          i <= 3 ? "bg-yellow-50 text-yellow-600 border-yellow-200" : "bg-gray-50 text-gray-300 border-gray-100 opacity-50"
                        )}>
                           <Sparkles className="w-6 h-6" />
                        </div>
                     ))}
                  </div>
                  <button className="w-full py-4 text-xs font-black uppercase tracking-widest text-gray-400 border border-dashed rounded-2xl hover:text-blue-600 hover:border-blue-200 transition-all">
                     View All Badges
                  </button>
               </div>
            </div>
          </motion.div>
        )}

        {activeCategory === 'buddy' && (
          <motion.div 
            key="buddy"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-12 rounded-[3.5rem] border shadow-sm text-center space-y-8"
          >
            <div className="w-24 h-24 bg-purple-50 text-purple-600 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
               <UsersIcon className="w-12 h-12" />
            </div>
            <div className="space-y-4">
               <h2 className="text-3xl font-black font-display tracking-tight">Study Buddy Finder</h2>
               <p className="text-gray-500 max-w-sm mx-auto">Connect with students studying the same subjects. Collaborative learning increases retention by 40%.</p>
            </div>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
               {[1, 2, 3].map(i => (
                  <div key={i} className="p-6 bg-gray-50 rounded-[2.5rem] border border-transparent hover:border-purple-200 transition-all group">
                     <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 text-purple-600 shadow-sm group-hover:scale-110 transition-transform">
                        <UsersIcon className="w-8 h-8" />
                     </div>
                     <h4 className="font-bold">Student #{i}34</h4>
                     <p className="text-xs text-gray-400 mb-4">Studying: Physics, Calculus</p>
                     <button 
                       onClick={() => handleBuddyRequest(i)}
                       className={cn(
                        "w-full py-3 rounded-xl text-xs font-bold transition-all",
                        buddyRequests.includes(i.toString()) 
                          ? "bg-green-100 text-green-600 cursor-default" 
                          : "bg-purple-600 text-white hover:bg-purple-700"
                       )}
                     >
                        {buddyRequests.includes(i.toString()) ? 'Request Sent' : 'Request Buddy'}
                     </button>
                  </div>
               ))}
            </div>
          </motion.div>
        )}

        {activeCategory === 'calc' && (
          <motion.div 
            key="calc"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-12 rounded-[3.5rem] border shadow-sm flex flex-col md:flex-row gap-12"
          >
             <div className="flex-1 space-y-8">
                <div className="space-y-1">
                   <h2 className="text-3xl font-black font-display tracking-tight">Grade Predictor</h2>
                   <p className="text-gray-500">Enter your expected scores to predict your CGPA.</p>
                </div>
                <div className="grid grid-cols-2 gap-6">
                   {Object.keys(scores).map(sub => (
                      <div key={sub} className="space-y-2">
                         <label className="text-xs font-black uppercase tracking-widest text-gray-400">{sub}</label>
                         <input 
                           type="number" 
                           placeholder="0-100"
                           className="w-full p-4 bg-gray-50 rounded-2xl border-none outline-none focus:ring-2 ring-green-500/20 text-lg font-bold"
                           value={scores[sub as keyof typeof scores]}
                           onChange={e => setScores({...scores, [sub]: e.target.value})}
                         />
                      </div>
                   ))}
                </div>
                <button 
                  onClick={calculateCgpa}
                  className="w-full py-5 bg-green-600 text-white rounded-[1.5rem] font-black text-lg hover:bg-green-700 transition-all flex items-center justify-center gap-2 shadow-xl shadow-green-500/20"
                >
                   <Calculator className="w-6 h-6" /> Calculate Predictor
                </button>
             </div>
             
             <div className="w-full md:w-80 bg-green-50 rounded-[3rem] p-10 flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center text-green-600 shadow-xl">
                   <Award className="w-10 h-10" />
                </div>
                <div>
                   <p className="text-xs font-black uppercase tracking-widest text-green-600 mb-1">Predicted CGPA</p>
                   <h3 className="text-6xl font-black text-gray-900 font-display">{cgpa || '0.0'}</h3>
                </div>
                <div className="w-full h-2 bg-white rounded-full overflow-hidden">
                   <motion.div 
                     initial={{ width: 0 }}
                     animate={{ width: `${(cgpa || 0) * 10}%` }}
                     className="h-full bg-green-500"
                   />
                </div>
                <p className="text-sm text-green-800 font-medium leading-relaxed">
                   {cgpa && cgpa > 8 ? "Excellent! You're on track for Honors." : "Keep pushing! Aim for the next bracket."}
                </p>
             </div>
          </motion.div>
        )}

        {activeCategory === 'voice' && (
          <motion.div 
            key="voice"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="relative overflow-hidden bg-gradient-to-br from-orange-500 to-red-600 text-white p-12 rounded-[4rem] flex flex-col items-center text-center space-y-8"
          >
             <div className="absolute top-0 right-0 p-10 opacity-10">
                <Mic className="w-64 h-64" />
             </div>
             <div className="px-8 py-3 bg-white/20 backdrop-blur-md rounded-2xl text-xs font-black uppercase tracking-widest border border-white/20">
                Experimental AI
             </div>
             <div className="space-y-4 max-w-2xl relative z-10">
                <h2 className="text-5xl font-black font-display tracking-tight leading-none">AI Audio Notes</h2>
                <p className="text-orange-100 text-lg">Convert your study notes into high-quality audio sessions using neural voice synthesis.</p>
             </div>
             <div className="flex gap-4 relative z-10">
                <button 
                  onClick={handleVoiceGenerate}
                  disabled={isGeneratingVoice}
                  className="px-12 py-5 bg-white text-orange-600 rounded-3xl font-black shadow-2xl hover:scale-105 transition-transform disabled:opacity-50"
                >
                   {isGeneratingVoice ? 'Generating...' : 'Upload & Generate'}
                </button>
             </div>
             <div className="flex gap-1 h-12 items-center relative z-10">
                {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                  <motion.div 
                    key={i}
                    animate={{ height: [10, 40, 10] }}
                    transition={{ duration: 0.5 + Math.random(), repeat: Infinity }}
                    className="w-1.5 bg-white/40 rounded-full"
                  />
                ))}
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
