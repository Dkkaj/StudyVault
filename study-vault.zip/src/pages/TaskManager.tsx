import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  Trash2, 
  Calendar, 
  Filter, 
  MoreHorizontal,
  Clock,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { cn, formatDate } from '../lib/utils';

interface Task {
  id: string;
  title: string;
  description: string;
  subject_name: string;
  due_date: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
}

export function TaskManager() {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskSubject, setNewTaskSubject] = useState('');
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');

  useEffect(() => {
    fetchTasks();
  }, [user, filter]);

  const fetchTasks = async () => {
    if (!user) return;
    setLoading(true);
    let query = supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    
    if (filter === 'pending') query = query.eq('completed', false);
    if (filter === 'completed') query = query.eq('completed', true);

    const { data } = await query;
    setTasks(data || []);
    setLoading(false);
  };

  const addTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim() || !user) return;

    const { error } = await supabase.from('tasks').insert({
      user_id: user.id,
      title: newTaskTitle,
      subject_name: newTaskSubject || 'Other',
      due_date: new Date().toISOString(),
      priority: 'medium'
    });

    if (!error) {
      setNewTaskTitle('');
      setNewTaskSubject('');
      fetchTasks();
    }
  };

  const toggleTask = async (task: Task) => {
    const { error } = await supabase
      .from('tasks')
      .update({ completed: !task.completed })
      .eq('id', task.id);
    
    if (!error) {
      setTasks(tasks.map(t => t.id === task.id ? { ...t, completed: !t.completed } : t));
    }
  };

  const deleteTask = async (id: string) => {
    const { error } = await supabase.from('tasks').delete().eq('id', id);
    if (!error) setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display">Daily Tasks</h1>
          <p className="text-gray-500">Organize your study sessions efficiently.</p>
        </div>
        <div className="flex bg-white border rounded-xl overflow-hidden shadow-sm">
          {(['all', 'pending', 'completed'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-4 py-2 text-xs font-bold uppercase tracking-widest transition-all",
                filter === f ? "bg-blue-600 text-white" : "text-gray-500 hover:bg-gray-50"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={addTask} className="bg-white p-6 rounded-[2rem] border shadow-xl shadow-blue-500/5 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 space-y-2">
            <input 
              type="text" 
              placeholder="What do you need to study today?"
              value={newTaskTitle}
              onChange={e => setNewTaskTitle(e.target.value)}
              className="w-full px-5 py-4 rounded-2xl bg-gray-50 border border-transparent focus:bg-white focus:border-blue-200 outline-none transition-all font-medium"
              required
            />
          </div>
          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="Subject"
              value={newTaskSubject}
              onChange={e => setNewTaskSubject(e.target.value)}
              className="w-32 px-5 py-4 rounded-2xl bg-gray-50 border border-transparent focus:bg-white focus:border-blue-200 outline-none transition-all text-sm"
            />
            <button 
              type="submit"
              className="px-6 py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-gray-800 active:scale-95 transition-all flex items-center gap-2"
            >
              <Plus className="w-5 h-5" /> Add Task
            </button>
          </div>
        </div>
      </form>

      <div className="space-y-4">
        {loading ? (
          [1, 2, 3].map(i => <div key={i} className="h-20 bg-gray-100/50 animate-pulse rounded-[2rem]" />)
        ) : tasks.length > 0 ? (
          <AnimatePresence mode="popLayout">
            {tasks.map((task) => (
              <motion.div
                layout
                key={task.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={cn(
                  "p-6 bg-white rounded-[2rem] border transition-all flex items-center gap-6 group hover:shadow-lg hover:shadow-blue-500/5",
                  task.completed ? "opacity-60 border-green-100" : "border-gray-100"
                )}
              >
                <button 
                  onClick={() => toggleTask(task)}
                  className={cn(
                    "w-8 h-8 rounded-xl flex items-center justify-center transition-all",
                    task.completed ? "bg-green-500 text-white" : "bg-gray-100 text-gray-400 group-hover:bg-blue-100 group-hover:text-blue-500"
                  )}
                >
                  {task.completed ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5 truncate" />}
                </button>

                <div className="flex-1">
                  <h3 className={cn("font-bold text-lg", task.completed && "line-through text-gray-400")}>
                    {task.title}
                  </h3>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">{task.subject_name}</span>
                    <span className="text-xs text-gray-400 flex items-center gap-1 font-medium italic">
                      <Clock className="w-3 h-3" /> Created {formatDate(new Date())}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => deleteTask(task.id)}
                    className="p-3 rounded-xl hover:bg-red-50 text-gray-300 hover:text-red-500 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        ) : (
          <div className="p-16 text-center bg-gray-50/50 rounded-[2.5rem] border-2 border-dashed border-gray-200">
             <div className="w-20 h-20 bg-gray-100 text-gray-300 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Plus className="w-10 h-10" />
             </div>
             <h3 className="text-xl font-bold text-gray-400">Empty List</h3>
             <p className="text-gray-400 text-sm max-w-xs mx-auto mt-2">Finish your tea and add some tasks to start your study session.</p>
          </div>
        )}
      </div>

      <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-8 rounded-[2.5rem] text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-blue-500/20 overflow-hidden relative">
        <div className="relative z-10 flex-1">
          <h3 className="text-2xl font-bold font-display">Need more power?</h3>
          <p className="text-blue-100 mt-2">Let AI prioritize your tasks based on exam dates and difficulty level.</p>
        </div>
        <button className="relative z-10 px-8 py-4 bg-white text-blue-600 rounded-2xl font-bold hover:scale-105 transition-all flex items-center gap-2">
          <Sparkles className="w-5 h-5" /> Optimize Checklist
        </button>
        <AlertCircle className="absolute -right-8 -bottom-8 w-48 h-48 text-white/10" />
      </div>
    </div>
  );
}
