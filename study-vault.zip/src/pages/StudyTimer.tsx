import React, { useState, useEffect } from 'react';
import { 
  Timer as TimerIcon, 
  Play, 
  Pause, 
  RotateCcw, 
  Coffee, 
  Brain,
  ChevronRight,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { cn } from '../lib/utils';

export function StudyTimer() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'study' | 'break'>('study');
  const [sessionsCompleted, setSessionsCompleted] = useState(0);

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
      handleSessionEnd();
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, timeLeft]);

  const handleSessionEnd = () => {
    if (mode === 'study') {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      setSessionsCompleted(s => s + 1);
      setMode('break');
      setTimeLeft(5 * 60);
    } else {
      setMode('study');
      setTimeLeft(25 * 60);
    }
  };

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'study' ? 25 * 60 : 5 * 60);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = ((mode === 'study' ? 25 * 60 : 5 * 60) - timeLeft) / (mode === 'study' ? 25 * 60 : 5 * 60) * 100;

  return (
    <div className="max-w-4xl mx-auto space-y-12 py-8">
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold font-display flex items-center justify-center gap-2">
          {mode === 'study' ? <Brain className="text-blue-600" /> : <Coffee className="text-green-600" />}
          {mode === 'study' ? 'Deep Work Session' : 'Take a Breath'}
        </h1>
        <p className="text-gray-500">Pomodoro Technique for maximum focus.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-12 items-center">
        {/* Timer UI */}
        <div className="flex flex-col items-center space-y-8">
          <div className="relative w-72 h-72 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90">
              <circle
                cx="144"
                cy="144"
                r="130"
                className="stroke-gray-100 fill-none"
                strokeWidth="8"
              />
              <motion.circle
                cx="144"
                cy="144"
                r="130"
                className={cn("fill-none transition-all duration-300", mode === 'study' ? "stroke-blue-600" : "stroke-green-500")}
                strokeWidth="10"
                strokeDasharray="816"
                style={{ strokeDashoffset: 816 - (816 * progress) / 100 }}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-6xl font-black font-display tracking-tighter text-gray-900">
                {formatTime(timeLeft)}
              </span>
              <span className="text-sm font-bold text-gray-400 uppercase tracking-widest mt-2">{mode}</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={resetTimer}
              className="p-4 rounded-2xl bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all font-bold"
            >
              <RotateCcw className="w-6 h-6" />
            </button>
            <button
              onClick={toggleTimer}
              className={cn(
                "px-12 py-4 rounded-2xl text-white font-bold text-lg shadow-xl transition-all active:scale-95 flex items-center gap-3",
                isActive ? "bg-red-500 shadow-red-200" : "gradient-bg shadow-blue-200"
              )}
            >
              {isActive ? <Pause className="fill-current" /> : <Play className="fill-current" />}
              {isActive ? 'Pause' : 'Start Focus'}
            </button>
          </div>
        </div>

        {/* Stats & Session History */}
        <div className="space-y-6">
          <div className="p-8 bg-white rounded-[2rem] border shadow-sm space-y-6">
             <h3 className="text-xl font-bold mb-4">Today's Progress</h3>
             <div className="grid grid-cols-2 gap-4">
               <div className="p-4 bg-blue-50 rounded-2xl text-center">
                  <span className="block text-2xl font-black text-blue-600">{sessionsCompleted}</span>
                  <span className="text-[10px] uppercase font-bold text-blue-400">Sessions</span>
               </div>
               <div className="p-4 bg-purple-50 rounded-2xl text-center">
                  <span className="block text-2xl font-black text-purple-600">{sessionsCompleted * 25}m</span>
                  <span className="text-[10px] uppercase font-bold text-purple-400">Total Study</span>
               </div>
             </div>

             <div className="pt-6 border-t space-y-4">
                <h4 className="font-bold text-sm text-gray-500 uppercase tracking-wider">Session Log</h4>
                <div className="space-y-3">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 border border-transparent hover:border-gray-100 transition-all">
                       <div className="flex items-center gap-3">
                         <div className={cn("w-2 h-2 rounded-full", i <= sessionsCompleted ? "bg-green-500" : "bg-gray-200")}></div>
                         <span className="text-sm font-medium text-gray-700">Deep Work Session #{i}</span>
                       </div>
                       <span className="text-xs text-gray-400 italic">25:00</span>
                    </div>
                  ))}
                </div>
             </div>
          </div>

          <div className="p-6 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl text-white shadow-lg overflow-hidden relative">
            <div className="relative z-10">
              <h4 className="font-bold">Next Milestone</h4>
              <p className="text-xs text-blue-100 opacity-80 mb-4">Complete 5 sessions to unlock "Fire" badge!</p>
              <div className="h-2 w-full bg-white/20 rounded-full">
                <div 
                  className="h-full bg-white transition-all duration-1000" 
                  style={{ width: `${(sessionsCompleted / 5) * 100}%` }}
                ></div>
              </div>
            </div>
            <TimerIcon className="absolute -right-4 -bottom-4 w-24 h-24 text-white/10" />
          </div>
        </div>
      </div>
    </div>
  );
}
