import React, { useState } from 'react';
import { 
  Music, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  Wind, 
  CloudRain, 
  Coffee, 
  Waves,
  Maximize2,
  Timer,
  Moon,
  Sun,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';

export function FocusMode() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeSound, setActiveSound] = useState<string | null>(null);
  const [volume, setVolume] = useState(0.5);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [timerActive, setTimerActive] = useState(false);

  React.useEffect(() => {
    let interval: any = null;
    if (timerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setTimerActive(false);
      alert('Focus session complete! Take a break.');
    }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const resetTimer = () => {
    setTimerActive(false);
    setTimeLeft(25 * 60);
  };

  const sounds = [
    { id: 'lofi', name: 'Lofi Beats', icon: Music, color: 'bg-indigo-500' },
    { id: 'rain', name: 'Rainfall', icon: CloudRain, color: 'bg-blue-400' },
    { id: 'coffee', name: 'Cafe Ambience', icon: Coffee, color: 'bg-amber-600' },
    { id: 'wind', name: 'Winter Wind', icon: Wind, color: 'bg-teal-400' },
    { id: 'ocean', name: 'Ocean Waves', icon: Waves, color: 'bg-cyan-500' },
  ];

  const toggleSound = (id: string) => {
    if (activeSound === id) {
      setActiveSound(null);
      setIsPlaying(false);
    } else {
      setActiveSound(id);
      setIsPlaying(true);
    }
  };

  return (
    <div className={cn(
      "min-h-screen -m-8 p-12 transition-colors duration-1000 flex flex-col",
      isDarkMode ? "bg-gray-950 text-white" : "bg-white text-gray-900"
    )}>
      <div className="flex justify-between items-center mb-12">
        <div className="space-y-1">
           <h1 className="text-3xl font-black font-display tracking-tighter">Deep Focus Mode</h1>
           <p className={isDarkMode ? "text-gray-500" : "text-gray-400"}>Zero distractions. Pure productivity.</p>
        </div>
        <div className="flex items-center gap-4">
           <button 
             onClick={() => setIsDarkMode(!isDarkMode)}
             className={cn(
                "p-4 rounded-3xl transition-all",
                isDarkMode ? "bg-white/5 border border-white/10 hover:bg-white/10" : "bg-gray-100 hover:bg-gray-200"
             )}
           >
             {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
           </button>
           <button className={cn(
             "px-8 py-4 rounded-3xl font-bold flex items-center gap-2 transition-all shadow-lg",
             isDarkMode ? "bg-white text-black hover:bg-gray-100 shadow-white/5" : "bg-black text-white hover:bg-gray-900 shadow-black/5"
           )}>
             <Maximize2 className="w-5 h-5" /> Fullscreen
           </button>
        </div>
      </div>

      <div className="flex-1 grid lg:grid-cols-2 gap-12 items-center">
        <div className="flex flex-col items-center justify-center space-y-12">
           <div className="relative">
              <AnimatePresence>
                 {(isPlaying || timerActive) && (
                    <>
                      <motion.div 
                        initial={{ scale: 0.8, opacity: 0.5 }}
                        animate={{ scale: 1.5, opacity: 0 }}
                        transition={{ duration: 3, repeat: Infinity }}
                        className="absolute inset-0 rounded-full bg-blue-500/20"
                      />
                      <motion.div 
                        initial={{ scale: 0.8, opacity: 0.5 }}
                        animate={{ scale: 1.8, opacity: 0 }}
                        transition={{ duration: 4, repeat: Infinity, delay: 1 }}
                        className="absolute inset-0 rounded-full bg-purple-500/10"
                      />
                    </>
                 )}
              </AnimatePresence>
              
              <div className={cn(
                "w-64 h-64 sm:w-80 sm:h-80 rounded-full border-8 flex flex-col items-center justify-center relative z-10 transition-colors",
                isDarkMode ? "border-white/5 bg-white/5" : "border-gray-100 bg-white shadow-xl"
              )}>
                 <span className="text-6xl sm:text-8xl font-black mb-2 font-display">{formatTime(timeLeft)}</span>
                 <p className={cn("text-xs font-black uppercase tracking-widest", isDarkMode ? "text-gray-500" : "text-gray-400")}>Focus Session</p>
              </div>
           </div>

           <div className="flex gap-4">
              <button 
                onClick={() => setTimerActive(!timerActive)}
                className={cn(
                  "p-6 rounded-[2rem] transition-all",
                  isDarkMode ? "bg-white/5 hover:bg-white/10" : "bg-gray-100 hover:bg-gray-200"
                )}
              >
                 {timerActive ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
              </button>
              <button 
                onClick={resetTimer}
                className={cn(
                  "p-6 rounded-[2rem] transition-all",
                  isDarkMode ? "bg-white text-black hover:scale-105" : "bg-black text-white hover:scale-105"
                )}
              >
                 <RotateCcw className="w-8 h-8" />
              </button>
           </div>
        </div>

        <div className="space-y-8">
           <div className={cn(
             "p-8 rounded-[3rem] border shadow-2xl",
             isDarkMode ? "bg-white/5 border-white/10 shadow-black" : "bg-white border-blue-50 shadow-blue-500/5"
           )}>
              <div className="flex items-center justify-between mb-8">
                 <h3 className="text-xl font-bold font-display">Ambient Space</h3>
                 <div className="flex items-center gap-3">
                    <Volume2 className="w-4 h-4 text-gray-500" />
                    <input 
                      type="range" 
                      min="0" max="1" step="0.01"
                      value={volume}
                      onChange={(e) => setVolume(parseFloat(e.target.value))}
                      className="w-24 h-1 bg-blue-600 rounded-full accent-blue-600"
                    />
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 {sounds.map((sound) => (
                    <button 
                      key={sound.id}
                      onClick={() => toggleSound(sound.id)}
                      className={cn(
                        "p-6 rounded-[2rem] border transition-all flex flex-col items-center gap-4 group",
                        activeSound === sound.id 
                          ? isDarkMode ? "bg-white/20 border-white/30" : "bg-blue-50 border-blue-200" 
                          : isDarkMode ? "bg-white/5 border-white/5 hover:bg-white/10" : "bg-gray-50 border-transparent hover:bg-white hover:border-gray-200 shadow-sm"
                      )}
                    >
                       <div className={cn(
                         "w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110",
                         sound.color,
                         "text-white shadow-lg"
                       )}>
                          <sound.icon className="w-6 h-6" />
                       </div>
                       <span className="text-sm font-bold">{sound.name}</span>
                       <div className="flex gap-1 h-3 items-end">
                          <AnimatePresence>
                            {activeSound === sound.id && [1, 2, 3].map(i => (
                              <motion.div 
                                key={i}
                                initial={{ height: 4 }}
                                animate={{ height: [4, 12, 4] }}
                                transition={{ duration: 0.5 + i * 0.2, repeat: Infinity }}
                                className={cn("w-1 rounded-full", isDarkMode ? "bg-white" : "bg-blue-600")}
                              />
                            ))}
                          </AnimatePresence>
                       </div>
                    </button>
                 ))}
              </div>
           </div>

           <div className={cn(
             "p-8 rounded-[3.5rem] flex items-center gap-6",
             isDarkMode ? "bg-white/5" : "bg-blue-50"
           )}>
              <div className="w-16 h-16 rounded-[1.5rem] bg-indigo-500 shadow-xl flex items-center justify-center text-white">
                 <Music className="w-8 h-8" />
              </div>
              <div className="flex-1">
                 <p className="text-xs font-black uppercase tracking-widest text-indigo-500 mb-1">Now Playing</p>
                 <h4 className="text-xl font-bold">{activeSound ? sounds.find(s => s.id === activeSound)?.name : 'Silence'}</h4>
                 <p className="text-sm text-gray-500">Study Ambience Radio</p>
              </div>
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-5 bg-white rounded-full text-indigo-500 shadow-xl flex items-center justify-center hover:scale-110 transition-transform"
              >
                 {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
              </button>
           </div>
        </div>
      </div>
    </div>
  );
}
