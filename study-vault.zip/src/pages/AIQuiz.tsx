import React, { useState } from 'react';
import { 
  Brain, 
  Target, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  ChevronRight, 
  Loader2,
  Sparkles,
  Trophy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import confetti from 'canvas-confetti';
import { generateQuiz } from '../services/geminiService';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

export function AIQuiz() {
  const { isPremium } = useAuth();
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState('medium');
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [quizFinished, setQuizFinished] = useState(false);

  const startQuiz = async () => {
    if (!isPremium) return alert("Upgrade to Pro to generate AI Quizzes!");
    if (!topic) return;

    setLoading(true);
    try {
      const data = await generateQuiz(topic, difficulty);
      setQuestions(data);
      setCurrentStep(0);
      setScore(0);
      setQuizFinished(false);
      setShowResult(false);
    } catch (e) {
      console.error(e);
      alert('Failed to generate quiz. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (index: number) => {
    if (showResult) return;
    setSelectedOption(index);
    setShowResult(true);
    if (index === questions[currentStep].correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const nextQuestion = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(c => c + 1);
      setSelectedOption(null);
      setShowResult(false);
    } else {
      setQuizFinished(true);
      if (score >= 3) {
        confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 } });
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold font-display gradient-text flex items-center justify-center gap-2">
          <Brain className="text-blue-600" />
          AI Quiz Lab
        </h1>
        <p className="text-gray-500 max-w-lg mx-auto text-sm md:text-base">
          Test your knowledge! Enter any topic and our AI will generate a unique challenge for you.
        </p>
      </div>

      {!questions.length || quizFinished ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 md:p-12 rounded-[2.5rem] border shadow-xl shadow-blue-500/5 text-center space-y-8"
        >
          {quizFinished ? (
            <div className="space-y-6">
              <div className="w-24 h-24 bg-yellow-50 text-yellow-500 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                <Trophy className="w-12 h-12" />
              </div>
              <h2 className="text-3xl font-black">Quiz Complete!</h2>
              <div className="flex justify-center gap-8">
                <div className="text-left">
                  <span className="block text-xs uppercase font-black text-gray-400">Your Score</span>
                  <span className="text-4xl font-black text-gray-900">{score}/{questions.length}</span>
                </div>
                <div className="text-left">
                  <span className="block text-xs uppercase font-black text-gray-400">Accuracy</span>
                  <span className="text-4xl font-black text-blue-600">{Math.round((score/questions.length)*100)}%</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mx-auto">
              <Target className="w-10 h-10" />
            </div>
          )}

          <div className="max-w-md mx-auto space-y-4 text-left">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">Topic to Challenge</label>
              <input 
                type="text" 
                placeholder="Ex: Quantum Physics, Photosynthesis..."
                value={topic}
                onChange={e => setTopic(e.target.value)}
                className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-transparent focus:bg-white focus:border-blue-200 outline-none transition-all"
              />
            </div>
            <div className="flex gap-4">
              {['easy', 'medium', 'hard'].map(d => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={cn(
                    "flex-1 py-3 rounded-xl border text-xs font-bold uppercase tracking-widest transition-all",
                    difficulty === d ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-500 hover:border-gray-200"
                  )}
                >
                  {d}
                </button>
              ))}
            </div>
            <button
              onClick={startQuiz}
              disabled={loading || !topic}
              className="w-full py-4 gradient-bg text-white font-black rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-5 h-5" /> {quizFinished ? 'Retry Quiz' : 'Generate Quiz'}</>}
            </button>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white p-8 md:p-10 rounded-[2.5rem] border shadow-sm space-y-8"
        >
          <div className="flex justify-between items-center bg-gray-50 p-4 rounded-2xl">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Question {currentStep + 1} of {questions.length}</span>
            <div className="flex gap-1">
              {questions.map((_, i) => (
                <div key={i} className={cn("h-1 w-8 rounded-full", i === currentStep ? "bg-blue-600" : i < currentStep ? "bg-green-500" : "bg-gray-200")}></div>
              ))}
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 leading-tight">
            {questions[currentStep].question}
          </h2>

          <div className="grid gap-4">
            {questions[currentStep].options.map((option, i) => (
              <button
                key={i}
                onClick={() => handleAnswer(i)}
                className={cn(
                  "flex items-center gap-4 p-5 rounded-2xl border text-left transition-all",
                  showResult 
                    ? i === questions[currentStep].correctAnswer 
                      ? "bg-green-50 border-green-500 text-green-700 font-bold" 
                      : i === selectedOption ? "bg-red-50 border-red-500 text-red-700" : "opacity-50 grayscale-50"
                    : "hover:bg-gray-50 hover:border-blue-200 active:scale-[0.99] bg-white border-gray-100"
                )}
              >
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center font-bold",
                  showResult && i === questions[currentStep].correctAnswer ? "bg-green-500 text-white" : "bg-gray-100 text-gray-500"
                )}>
                  {String.fromCharCode(65 + i)}
                </div>
                <span className="flex-1">{option}</span>
                {showResult && i === questions[currentStep].correctAnswer && <CheckCircle2 className="w-6 h-6 text-green-500" />}
                {showResult && i === selectedOption && i !== questions[currentStep].correctAnswer && <XCircle className="w-6 h-6 text-red-500" />}
              </button>
            ))}
          </div>

          <AnimatePresence>
            {showResult && (
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                onClick={nextQuestion}
                className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl flex items-center justify-center gap-2 hover:bg-gray-800 transition-all shadow-xl shadow-gray-200"
              >
                {currentStep === questions.length - 1 ? 'See Your Rank' : 'Next Question'}
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}
