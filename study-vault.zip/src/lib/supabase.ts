import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://qdabndizsujaxktbmxjb.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_k0uCgoyY90GGxRGdT2boSQ_SXXdLqmU';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
