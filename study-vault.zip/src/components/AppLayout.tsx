import React from 'react';
import { Outlet, Navigate, useNavigate } from 'react-router-dom';
import { Sidebar, MobileNav } from './Navigation';
import { useAuth } from '../contexts/AuthContext';
import { Loader2, Bell, Search, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function AppLayout() {
  const { user, loading, profile, isAdmin } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-50">
        <Loader2 className="w-10 h-10 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex bg-gray-50 min-h-screen">
      <Sidebar />
      <main className="flex-1 pb-24 lg:pb-0 overflow-x-hidden">
        <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4 flex-1">
            <h2 
              className="text-xl font-semibold hidden md:block cursor-default select-none"
            >
              Welcome, {profile?.full_name || 'Student'}!
            </h2>
            <div className="relative max-w-md w-full ml-auto md:ml-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search subjects, notes..." 
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-gray-100 border-transparent focus:bg-white focus:border-blue-200 outline-none transition-all text-sm"
              />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 rounded-xl hover:bg-gray-100 relative">
              <Bell className="w-5 h-5 text-gray-600" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div 
              className="h-8 w-8 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white cursor-pointer select-none"
            >
              <UserIcon className="w-5 h-5" />
            </div>
          </div>
        </header>
        
        <div className="p-6 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      <MobileNav />
    </div>
  );
}
