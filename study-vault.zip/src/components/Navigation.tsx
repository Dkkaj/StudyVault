import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Calendar, 
  BookOpen, 
  CheckSquare, 
  Timer, 
  FileText, 
  Trophy, 
  Settings, 
  LogOut,
  ShieldCheck,
  CreditCard,
  Target,
  Brain,
  Layers,
  Archive,
  Edit3,
  Zap,
  User,
  Heart
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/' },
  { id: 'planner', label: 'AI Planner', icon: Calendar, path: '/planner' },
  { id: 'quiz', label: 'AI Quiz', icon: Brain, path: '/quiz' },
  { id: 'flashcards', label: 'Flashcards', icon: Layers, path: '/flashcards' },
  { id: 'notes', label: 'Scribble Notes', icon: Edit3, path: '/notes' },
  { id: 'resources', label: 'Study Hub', icon: Archive, path: '/resources' },
  { id: 'focus', label: 'Deep Focus', icon: Zap, path: '/focus' },
  { id: 'tasks', label: 'Tasks', icon: CheckSquare, path: '/tasks' },
  { id: 'timer', label: 'Timer', icon: Timer, path: '/timer' },
  { id: 'leaderboard', label: 'Rankings', icon: Trophy, path: '/leaderboard' },
];

export function Sidebar() {
  const { user, isAdmin, isPremium, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-white border-r h-screen sticky top-0">
      <div className="p-6 border-b">
        <h1 className="text-2xl font-black gradient-text flex items-center gap-2">
          <BookOpen className="text-blue-600" />
          Study Vault
        </h1>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
        {!isAdmin ? (
          <>
            {navItems.map((item) => (
              <NavLink
                key={item.id}
                to={item.path}
                className={({ isActive }) => cn(
                  "flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 group text-sm font-bold",
                  isActive 
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-500/20" 
                    : "text-gray-500 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                <item.icon className="w-5 h-5 shrink-0" />
                {item.label}
              </NavLink>
            ))}

            <NavLink
              to="/subscription"
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-black text-xs uppercase tracking-widest mt-4 text-center justify-center shadow-lg shadow-blue-500/20",
                isPremium 
                  ? "bg-gray-100 text-gray-500 hover:bg-gray-200" 
                  : "bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:opacity-90 transition-all"
              )}
            >
              {isPremium ? <CreditCard className="w-4 h-4" /> : <Zap className="w-4 h-4 fill-current" />}
              {isPremium ? 'My Subscription' : 'Go Premium'}
            </NavLink>
          </>
        ) : (
          <NavLink
            to="/admin"
            className={({ isActive }) => cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm bg-purple-50 text-purple-600 border border-purple-100",
              isActive ? "bg-purple-600 text-white shadow-lg shadow-purple-500/20 shadow-xl" : ""
            )}
          >
            <ShieldCheck className="w-5 h-5" />
            Admin Panel
          </NavLink>
        )}
      </nav>

      <div className="p-4 border-t space-y-2">
        <NavLink 
          to="/profile"
          className={({ isActive }) => cn(
            "flex items-center gap-3 px-3 py-3 w-full rounded-xl transition-all group",
            isActive ? "bg-gray-100" : "hover:bg-gray-50"
          )}
        >
          <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center group-hover:bg-blue-100 transition-colors border shadow-sm">
            <User className="w-5 h-5 text-gray-500 group-hover:text-blue-600" />
          </div>
          <div className="flex-1 min-w-0">
             <p className="text-xs font-black text-gray-900 truncate">{profile?.full_name || 'Set Name'}</p>
             <p className="text-[10px] text-gray-400 truncate tracking-tight font-bold">{profile?.unique_study_id}</p>
          </div>
        </NavLink>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 w-full text-left rounded-xl text-gray-400 hover:bg-red-50 hover:text-red-600 transition-all font-bold text-xs uppercase tracking-widest"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </aside>
  );
}

export function MobileNav() {
  const { isAdmin } = useAuth();
  
  if (isAdmin) {
    return (
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t px-4 py-2 flex justify-center items-center z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
        <NavLink to="/admin" className={({ isActive }) => cn("flex flex-col items-center p-3 rounded-xl transition-all", isActive ? "text-purple-600 bg-purple-50" : "text-gray-400")}>
          <ShieldCheck className="w-8 h-8" />
          <span className="text-[10px] font-black uppercase mt-1">Admin Panel</span>
        </NavLink>
      </nav>
    );
  }

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t px-4 py-2 flex justify-between items-center z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
      <NavLink to="/" className={({ isActive }) => cn("flex flex-col items-center p-2 rounded-xl transition-all", isActive ? "text-blue-600 bg-blue-50" : "text-gray-400")}>
        <LayoutDashboard className="w-6 h-6" />
        <span className="text-[10px] font-black uppercase mt-1">Home</span>
      </NavLink>
      <NavLink to="/planner" className={({ isActive }) => cn("flex flex-col items-center p-2 rounded-xl transition-all", isActive ? "text-blue-600 bg-blue-50" : "text-gray-400")}>
        <Calendar className="w-6 h-6" />
        <span className="text-[10px] font-black uppercase mt-1">AI</span>
      </NavLink>
      <NavLink to="/resources" className={({ isActive }) => cn("flex flex-col items-center p-2 rounded-xl transition-all", isActive ? "text-blue-600 bg-blue-50" : "text-gray-400")}>
        <Archive className="w-6 h-6" />
        <span className="text-[10px] font-black uppercase mt-1">Hub</span>
      </NavLink>
      <NavLink to="/focus" className={({ isActive }) => cn("flex flex-col items-center p-2 rounded-xl transition-all", isActive ? "text-blue-600 bg-blue-50" : "text-gray-400")}>
        <Zap className="w-6 h-6" />
        <span className="text-[10px] font-black uppercase mt-1">Focus</span>
      </NavLink>
      <NavLink to="/subscription" className={({ isActive }) => cn("flex flex-col items-center p-2 rounded-xl transition-all", isActive ? "text-blue-600 bg-blue-50" : "text-gray-400")}>
        <CreditCard className="w-6 h-6" />
        <span className="text-[10px] font-black uppercase mt-1">Plans</span>
      </NavLink>
      <NavLink to="/profile" className={({ isActive }) => cn("flex flex-col items-center p-2 rounded-xl transition-all", isActive ? "text-blue-600 bg-blue-50" : "text-gray-400")}>
        <User className="w-6 h-6" />
        <span className="text-[10px] font-black uppercase mt-1">Profile</span>
      </NavLink>
    </nav>
  );
}
