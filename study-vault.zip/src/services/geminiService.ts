import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: (process as any).env.GEMINI_API_KEY 
});

export const generateStudyPlan = async (subjects: string[], chapters: string[], examDate: string, targetHours: number) => {
  const prompt = `As an expert study coach, generate a highly effective study plan for a student.
  Subjects: ${JSON.stringify(subjects)}
  Chapters: ${JSON.stringify(chapters)}
  Exam Date: ${examDate}
  Available hours per day: ${targetHours}
  
  Format the response as pure JSON.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          timetable: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.STRING },
                subject: { type: Type.STRING },
                chapter: { type: Type.STRING },
                duration: { type: Type.STRING },
                focus: { type: Type.STRING }
              }
            }
          },
          revisionSchedule: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                date: { type: Type.STRING },
                topic: { type: Type.STRING },
                method: { type: Type.STRING }
              }
            }
          },
          dailyGoals: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          motivation: { type: Type.STRING }
        }
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export const generateQuiz = async (topic: string, difficulty: string) => {
  const prompt = `Generate a 5-question multiple choice quiz on the topic: ${topic}. Difficulty: ${difficulty}.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
            correctAnswer: { type: Type.NUMBER, description: "Index of the correct answer (0-3)" }
          },
          required: ["question", "options", "correctAnswer"]
        }
      }
    }
  });

  return JSON.parse(response.text || '[]');
};
