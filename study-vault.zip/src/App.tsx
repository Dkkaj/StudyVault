import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { AppLayout } from './components/AppLayout';
import { Login, Signup } from './pages/Auth';
import { Dashboard } from './pages/Dashboard';
import { StudyPlanner } from './pages/StudyPlanner';
import { Subscription } from './pages/Subscription';
import { AdminPanel } from './pages/AdminPanel';
import { StudyTimer } from './pages/StudyTimer';
import { Leaderboard } from './pages/Leaderboard';
import { AIQuiz } from './pages/AIQuiz';
import { TaskManager } from './pages/TaskManager';
import { Flashcards } from './pages/Flashcards';
import { Resources } from './pages/Resources';
import { Notes } from './pages/Notes';
import { FocusMode } from './pages/FocusMode';
import { Profile } from './pages/Profile';
import { Sparkles } from 'lucide-react';
import './index.css';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          
          <Route element={<AppLayout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/planner" element={<StudyPlanner />} />
            <Route path="/timer" element={<StudyTimer />} />
            <Route path="/subscription" element={<Subscription />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/quiz" element={<AIQuiz />} />
            <Route path="/tasks" element={<TaskManager />} />
            <Route path="/flashcards" element={<Flashcards />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/notes" element={<Notes />} />
            <Route path="/focus" element={<FocusMode />} />
            <Route path="/profile" element={<Profile />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
