import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  isPremium: boolean;
  isActive: boolean;
  profile: any | null;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (u: User) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', u.id)
        .single();
      
      if (data) {
        setProfile(data);
      } else if (error && error.code === 'PGRST116') {
        // user doesn't exist in our table yet, create manually
        const { data: newData, error: insertError } = await supabase
          .from('users')
          .insert({
            id: u.id,
            email: u.email,
            full_name: u.user_metadata?.full_name || 'Student',
            role: u.email === 'kprince43703@gmail.com' ? 'admin' : 'user',
            unique_study_id: Math.random().toString(36).substring(2, 12).toUpperCase()
          })
          .select()
          .single();
        
        if (newData) setProfile(newData);
        if (insertError) console.error("Manual profile creation failed", insertError);
      }
    } catch (e) {
      console.error("Error fetching profile", e);
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) fetchProfile(session.user);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) fetchProfile(session.user);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const refreshProfile = async () => {
    if (user) await fetchProfile(user);
  };

  const isAdmin = profile?.role === 'admin' || 
                  user?.email === 'kprince43703@gmail.com' ||
                  user?.email === 'yadavsarkaryadav218@gmail.com';
  const isPremium = profile?.subscription_status === 'active';
  const isActive = profile?.is_active !== false;

  return (
    <AuthContext.Provider value={{ user, session, loading, isAdmin, isPremium, profile, refreshProfile, isActive }}>
      {loading ? (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : !isActive && user?.email !== 'kprince43703@gmail.com' ? (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
          <div className="max-w-md w-full bg-white p-8 rounded-[2rem] border shadow-sm text-center space-y-4">
             <div className="w-20 h-20 bg-red-50 text-red-600 rounded-3xl flex items-center justify-center mx-auto">
                <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
             </div>
             <h1 className="text-2xl font-bold">Account Disabled</h1>
             <p className="text-gray-500">Your account has been deactivated by the administrator. Please contact support if you believe this is an error.</p>
             <button onClick={() => supabase.auth.signOut()} className="w-full py-3 bg-gray-900 text-white rounded-xl font-bold">Logout</button>
          </div>
        </div>
      ) : (
        children
      )}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
